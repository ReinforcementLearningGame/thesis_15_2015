This white_Neural ANN was trained with 320000 elimination games on Rhombus_small map.
Please make a copy of this in your applications root folder and use the following settings:
Map: Rhombus_small.gxl
Pawns per player: 4
Max turns: 1000
First Player: White
Win by Elimination only: YES/True
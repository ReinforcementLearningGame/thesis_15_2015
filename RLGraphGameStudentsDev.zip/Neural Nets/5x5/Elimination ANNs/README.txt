This white_Neural ANN was trained with elimination games on 5x5 map.
Please make a copy of this in your applications root folder and use the following settings:
Map: 5x5.gxl
Pawns per player: 5
Max turns: 1000
First Player: White
Win by Elimination only: YES/True
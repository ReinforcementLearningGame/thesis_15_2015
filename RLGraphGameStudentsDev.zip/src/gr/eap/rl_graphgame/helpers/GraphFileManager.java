/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers;

import edu.uci.ics.jung.graph.DirectedSparseMultigraph;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.io.GraphIOException;
import edu.uci.ics.jung.io.GraphMLWriter;
import edu.uci.ics.jung.io.graphml.EdgeMetadata;
import edu.uci.ics.jung.io.graphml.GraphMLReader2;
import edu.uci.ics.jung.io.graphml.GraphMetadata;
import edu.uci.ics.jung.io.graphml.HyperEdgeMetadata;
import edu.uci.ics.jung.io.graphml.NodeMetadata;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.collections15.Transformer;
import gr.eap.rl_graphgame.graph_elements.MapEdge;
import gr.eap.rl_graphgame.graph_elements.MapEdge.MapEdgeFactory;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import gr.eap.rl_graphgame.graph_elements.MapNode.MapNodeFactory;

/**
 * A class that manages the correct saving and loading of graphs to disk.
 * Special Thanks to Emaad Ahmed Manzoor and his blog https://halfclosed.wordpress.com/ for large parts of the following code
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class GraphFileManager {
    DirectedSparseMultigraph g;
    File filename;
    
    /**
     * Constructor
     */
    GraphFileManager(){
        this.g = new DirectedSparseMultigraph<MapNode,MapEdge>();
    }
    
    /**
     * Constructor with containing graph for the map nodes
     * @param g 
     */
    GraphFileManager(Graph g){
        this.g = (DirectedSparseMultigraph) g;
    }
    
    /**
     * Saves the graph to file
     * @param filename the filename to be saved
     * @throws NullPointerException .
     */
    public void saveGraphML (File filename)throws NullPointerException{
        GraphMLWriter<MapNode, MapEdge> graphWriter =
                 new GraphMLWriter<MapNode, MapEdge> ();
        PrintWriter out = null;
        try {
            out = new PrintWriter(
                    new BufferedWriter(
                            new FileWriter(filename)));
        } catch (IOException ex) {
            Logger.getLogger(GraphFileManager.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error saving Graph. IOException thrown.");
        }
        //add Vertex data for Base status
        graphWriter.addVertexData("Base of Player", null, "0",
        new Transformer<MapNode, String>() {
            @Override
            public String transform(MapNode v) {
            return Integer.toString(v.getBaseOfPlayer());
            }
        }
        );
        //add Vertex data for occupation status
        graphWriter.addVertexData("Occupied By", null, "0",
        new Transformer<MapNode, String>() {
            @Override
            public String transform(MapNode v) {
            return Integer.toString(v.getOccupiedBy());
            }
        }
        );
        
        
        try {
            graphWriter.save(g, out);
        } catch (IOException ex) {
            Logger.getLogger(GraphFileManager.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error saving Graph. Unable to write graph to printwriter");
            return;
        }
        
        out.close();
    }
    
    /**
     * Loads a Graph from a filename
     * @param filename The saved graph filename
     * @return The loaded graph
     * @throws NullPointerException .
     */
    public DirectedSparseMultigraph loadGraphML (File filename) throws NullPointerException {
        MapNode.setContainingGraph(g); //set this graph as containing graph for the new vertices until the whole graph is loaded (required for MapNode object instantiation
        BufferedReader fileReader;
        try {
            fileReader = new BufferedReader(new FileReader(filename));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GraphFileManager.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error loading Graph. File not found!");
            return null;
        }
        // The Graph Transformer
        Transformer<GraphMetadata, Graph<MapNode, MapEdge>> graphTransformer = new Transformer<GraphMetadata,Graph<MapNode, MapEdge>>() {
            @Override
            public Graph<MapNode, MapEdge> transform(GraphMetadata metadata) {
                if (metadata.getEdgeDefault().equals(metadata.getEdgeDefault().DIRECTED)) {
                    return new DirectedSparseMultigraph<MapNode, MapEdge>();
                } else {
                    return new UndirectedSparseGraph<MapNode, MapEdge>();
                }
            }
        };
        //The vertex transformer
        Transformer<NodeMetadata, MapNode> vertexTransformer = new Transformer<NodeMetadata, MapNode>() {
            @Override
            public MapNode transform(NodeMetadata metadata) {
                MapNode v = MapNodeFactory.getInstance().create();
                v.setBaseOfPlayer(Integer.parseInt(metadata.getProperty("Base of Player")));
                v.setOccupiedBy(Integer.parseInt(metadata.getProperty("Occupied By")));
                return v;
            }
        };
        
        //The Edge Transformer
        /* Create the Edge Transformer */
        Transformer<EdgeMetadata, MapEdge> edgeTransformer = new Transformer<EdgeMetadata, MapEdge>() {
            @Override
            public MapEdge transform(EdgeMetadata metadata) {
                MapEdge e = MapEdgeFactory.getInstance().create();
                return e;
            }
        };
        
        // The Hyperedge Transformer
        Transformer<HyperEdgeMetadata, MapEdge> hyperEdgeTransformer = new Transformer<HyperEdgeMetadata, MapEdge>() {
            @Override
            public MapEdge transform(HyperEdgeMetadata metadata) {
                MapEdge e = MapEdgeFactory.getInstance().create();
                return e;
            }
        };
        
        //Instantiate the graphMLReader2
        GraphMLReader2<Graph<MapNode, MapEdge>, MapNode, MapEdge> graphReader = new GraphMLReader2<Graph<MapNode, MapEdge>, MapNode, MapEdge> 
              (fileReader, graphTransformer, vertexTransformer, edgeTransformer, hyperEdgeTransformer);
        
        try {
            g = (DirectedSparseMultigraph) graphReader.readGraph();
        } catch (GraphIOException ex) {
            System.out.println("Load Graph failed. IO Exception thrown.");
            Logger.getLogger(GraphFileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            fileReader.close();
        } catch (IOException ex) {
            Logger.getLogger(GraphFileManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        MapNode.setContainingGraph(g); //set the newly loaded graph as the containing graph for the MapNodes
        
        
        
        return g;
        
        
    }
    
    
}

/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers.editor_utilities;

import edu.uci.ics.jung.visualization.VisualizationViewer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JDialog;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gr.eap.rl_graphgame.graph_elements.MapEdge;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import gr.eap.rl_graphgame.environment.Settings;

/**
 * A collection of classes used to assemble popup mouse menus for the custom
 * edges and vertices developed in this example.
 * Thanks to Dr. Greg M. Bernstein's JUNG 2 Tutorials. http://www.grotto-networking.com/ 
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class MyMouseMenus {
    
    public static class EdgeMenu extends JPopupMenu {        
        // private JFrame dialog; 
        public EdgeMenu(final JDialog dialog) {
            super("Edge Menu");
            this.add(new DeleteEdgeMenuItem<MapEdge>());
            this.addSeparator();
            this.add(new WeightDisplay());
        }
        
    }
    
    public static class EdgePropItem extends JMenuItem implements EdgeMenuListener<MapEdge>,
            MenuPointListener {
        MapEdge edge;
        VisualizationViewer visComp;
        Point2D point;
        
        public void setEdgeAndView(MapEdge edge, VisualizationViewer visComp) {
            this.edge = edge;
            this.visComp = visComp;
        }

        public void setPoint(Point2D point) {
            this.point = point;
        }

        
    }
    public static class WeightDisplay extends JMenuItem implements EdgeMenuListener<MapEdge> {
        public void setEdgeAndView(MapEdge e, VisualizationViewer visComp) {
            this.setText("Weight " + e + " = " + e.getWeight());
        }
    }
    
    
    public static class VertexMenu extends JPopupMenu {
        public VertexMenu() {
            super("Vertex Menu");
            this.add(new DeleteVertexMenuItem<MapNode>());
            this.addSeparator();
            this.add(new WhiteBaseBox());
            this.add(new BlackBaseBox());
        }
    }
    
    public static class WhiteBaseBox extends JCheckBoxMenuItem implements VertexMenuListener<MapNode> {
        MapNode v;
        
        public WhiteBaseBox() {
            super("White Player Base");
            this.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    v.setBaseOfPlayer(Settings.WHITE_ID);    
                }
                
            });
        }
        public void setVertexAndView(MapNode v, VisualizationViewer visComp) {
            this.v = v;
            this.setSelected(v.getBaseOfPlayer() == Settings.WHITE_ID);
        }
        
    }
    
        public static class BlackBaseBox extends JCheckBoxMenuItem implements VertexMenuListener<MapNode> {
        MapNode v;
        
        public BlackBaseBox() {
            super("Black Player Base");
            this.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    v.setBaseOfPlayer(Settings.BLACK_ID);

                }
                
            });
        }
        public void setVertexAndView(MapNode v, VisualizationViewer visComp) {
            this.v = v;
            this.setSelected(v.getBaseOfPlayer() == Settings.BLACK_ID);
        }
        
    }
    
}

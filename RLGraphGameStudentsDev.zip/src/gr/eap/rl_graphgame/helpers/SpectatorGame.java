/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers;

import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.PluggableGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.TranslatingGraphMousePlugin;
import java.awt.event.MouseEvent;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;
import gr.eap.rl_graphgame.player_types.ComputerPlayer;

/**
 * The user may spectate a game between two computer players. The last defined settings are used
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class SpectatorGame extends GameWindow{
    
    /**
     * The first player to play
     */
    private ComputerPlayer firstPlayer;
    /**
     * The second player to play
     */
    private ComputerPlayer secondPlayer;
    
    /**
     * Creates the mouse interface for the user
     */
    @Override
    protected void createMouseInterface(){
        //create and add the players mouse functionality
        PluggableGraphMouse mouse = new PluggableGraphMouse();
        mouse.add(new TranslatingGraphMousePlugin(MouseEvent.BUTTON2_MASK));
        mouse.add(new ScalingGraphMousePlugin(new CrossoverScalingControl(), 0, 1.1f, 0.9f));
        visualizationViewer.setGraphMouse(mouse); 
    }
    
    /**
     * Sets up the single player game required objects. world, players, map etc
     */
    @Override
    protected void createGame() {
        System.out.println("Creating Single Player Game");
        System.out.println("Creating World map.");
        gameWorld = new World(map);
        System.out.println("Creating White Computer Player");
        whitePlayer = new ComputerPlayer(Settings.WHITE_ID, Settings.BLACK_ID, gameWorld.findWhiteBase(), Settings.NUMBER_OF_PAWNS, this.gameWorld );
        gameWorld.setWhitePlayer(whitePlayer);
        System.out.println("Creating Black Computer Player");
        blackPlayer = new ComputerPlayer(Settings.BLACK_ID, Settings.WHITE_ID, gameWorld.findBlackBase(), Settings.NUMBER_OF_PAWNS, this.gameWorld );
        gameWorld.setBlackPlayer(blackPlayer);
        ((ComputerPlayer)whitePlayer).initialize();
        ((ComputerPlayer)blackPlayer).initialize();
        
        if (Settings.FIRST_PLAYER == Settings.WHITE_ID){
            firstPlayer = (ComputerPlayer) whitePlayer;
            secondPlayer = (ComputerPlayer) blackPlayer;
        } else{
            firstPlayer = (ComputerPlayer) blackPlayer;
            secondPlayer = (ComputerPlayer) whitePlayer;
        }
        
    }
    
    
    
    /**
     * controls the flow of the single player game
     */
    @Override
    public void play(){
        
        unmarkMoves();
        
        if (winner!=null)
            gameWindow.dispose();
        log("Turn "+turn ++);
        
        PawnAction action;
        action = firstPlayer.chooseAction(turn);
        log("Player "+firstPlayer.getPlayerId() + (action.isExploiting() ? " EXPLOITING...": "EXPLORING...") );
        gameWorld.applyAction(action);
        //Remove next comment to let the player learn while the user is spectating
        //firstPlayer.learnFromAction(action);
        markMove(action);
        winner = gameWorld.isFinalState();
        if (winner == null){
            //System.out.println("**************BLACK****M O V E S***************");
            action = secondPlayer.chooseAction(turn);
            log("Player "+secondPlayer.getPlayerId() + (action.isExploiting() ? " EXPLOITING...": "EXPLORING...") );
            gameWorld.applyAction(action);
            //Remove next comment to let the player learn while the user is spectating
            //secondPlayer.learnFromAction(action);
            markMove(action);
            winner = gameWorld.isFinalState();
        }

        whitePawnsInBaseLabel.setText("White Pawns In Base: "+whitePlayer.getPawnsInBase());
        whitePawnsAliveLabel.setText("White Pawns Remaining: "+whitePlayer.getAlivePawns().size());
        blackPawnsInBaseLabel.setText("Black Pawns In Base: "+blackPlayer.getPawnsInBase());
        blackPawnsAliveLabel.setText("Black Pawns Remaining: "+blackPlayer.getAlivePawns().size());
        

        if (winner!=null){
            log("PLAYER "+winner.getPlayerId()+" WINS!!!");
            firstPlayer.finishGame();
            secondPlayer.finishGame();
            endGame();
        }
        
        
            
        
        
    }
    
    /**
     * Next turn button functionality
     * @param evt the button event
     */    
    @Override
    protected void nextTurnButtonActionPerformed(java.awt.event.ActionEvent evt) {                                               
        play();
    }
}

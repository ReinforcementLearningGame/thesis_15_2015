/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers;

import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;
import gr.eap.rl_graphgame.game_utilities.SinglePlayerMouse;
import gr.eap.rl_graphgame.player_types.ComputerPlayer;
import gr.eap.rl_graphgame.player_types.HumanTeacher;
import java.awt.event.ActionEvent;

/**
 * Creates a game where the user's moves are "learned" by the computer player. The player is actually the computers instructor
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class TeacherGame extends GameWindow{    
    
    
    /**
     * Sets up the single player game required objects. world, players, map etc
     */
    @Override
    protected void createGame() {
        System.out.println("Creating Teacher - Player Game");
        System.out.println("Creating World map.");
        gameWorld = new World(map);
        System.out.println("Creating Human Player");
        whitePlayer = new HumanTeacher(Settings.WHITE_ID, Settings.BLACK_ID, gameWorld.findWhiteBase(), Settings.NUMBER_OF_PAWNS, gameWorld, this);
        gameWorld.setWhitePlayer(whitePlayer);
        System.out.println("Creating Black Computer Player");
        blackPlayer = new ComputerPlayer(Settings.BLACK_ID, Settings.WHITE_ID, gameWorld.findBlackBase(), Settings.NUMBER_OF_PAWNS, this.gameWorld );
        gameWorld.setBlackPlayer(blackPlayer);
        ((HumanTeacher)whitePlayer).initialize();
       
        ((ComputerPlayer)blackPlayer).initialize();
    }
    
    
    
    /**
     * controls the flow of the single player teacher game
     */
    protected void play(){
//        System.out.println("White pawns in base " + whitePlayer.getPawnsInBase());
//        System.out.println("Black pawns in base " + blackPlayer.getPawnsInBase());
//        
        
        PawnAction action;
        turn++;
        unmarkMoves();
        
        if (turn == 1){
            log("Turn "+turn);
            log("White Player's turn");
        } 
            
        
        action = whitePlayer.chooseAction(turn);
        
        if (action!=null){
            gameWorld.applyAction(action);
            log("White Player moving from " + action.getSource() + " to " + action.getTarget());
        }
            
        else {
            if (turn!=1)
                log("No valid action chosen");
            return;
        }
//        System.out.println(this +" play move" + startingPosition + " "+ targetPosition);
        markMove(action);
        whitePlayer.learnFromAction(action);
        winner = gameWorld.isFinalState();
        
        log("Black player's turn.");
        if (winner == null){
            //System.out.println("**************C P U ****M O V E S***************");
            action = blackPlayer.chooseAction(turn);
            log("Black Player moving from " + action.getSource() + " to " + action.getTarget());
            gameWorld.applyAction(action);
            markMove(action);
            
            blackPlayer.learnFromAction(action);
            winner = gameWorld.isFinalState();
            if (winner == blackPlayer){
                log("Black Player WINS!");
                endGame();
                if (gameWorld == null) //if the player doesn't wish to play another game return;
                    return;
            }
        } else{
            log("White Player WINS!");
            endGame();
            if (gameWorld == null) //if the player doesn't wish to play another game return;
                    return;
        }
        
        //reset the players choice so as to get a fresh one next turn
        startingPosition = null;
        targetPosition = null;
        
        log("Turn "+turn);
        log("White Player's turn.");
        
        whitePawnsInBaseLabel.setText("White Pawns In Base: "+ whitePlayer.getPawnsInBase());
        whitePawnsAliveLabel.setText("White Pawns Remaining: "+ whitePlayer.getAlivePawns().size());
        blackPawnsInBaseLabel.setText("Black Pawns In Base: "+blackPlayer.getPawnsInBase());
        blackPawnsAliveLabel.setText("Black Pawns Remaining: "+blackPlayer.getAlivePawns().size());

    }

    /**
     * The mouse interface for the teacher
     */
    @Override
    protected void createMouseInterface() {
        //create and add the players mouse
        SinglePlayerMouse spm = new SinglePlayerMouse(this, gameWorld.getWhitePlayer());
        visualizationViewer.setGraphMouse(spm); 
        visualizationViewer.addGraphMouseListener(spm);
    }

    /**
     * Next turn button functionality
     * @param evt the button event
     */
    @Override
    protected void nextTurnButtonActionPerformed(ActionEvent evt) {
        //log("Next Turn Pressed.");
        if ( startingPosition !=null && targetPosition != null)
            play();
        else
            log("Invalid move selected");
    }
}

/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.player_types;

import gr.eap.rl_graphgame.helpers.SinglePlayerGame;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.helpers.GameWindow;

/**
 * The class of the Human player
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class HumanPlayer extends Player{
    /**
     * The players nr of pawns
     */
    protected int numberOfPawns;
    
    /**
     * A reference to the game window/GUI that plays/presents the game
     */
    protected GameWindow game;

    /**
     * Constructor for Human Player
     * @param playerId  The players ID nr
     * @param playerBase    The position of the players base
     * @param numberOfPawns     The players nr of pawns
     */
    public HumanPlayer(int playerId, Position playerBase, int numberOfPawns) {
        super(playerId, playerBase, numberOfPawns);
        game = null;
    }

    /**
     * Constructor for Human player
     * @param playerId  The players ID nr
     * @param playerBase    The position of the players base
     * @param numberOfPawns     The players nr of pawns
     * @param game A reference to the game's gui
     */
    public HumanPlayer(int playerId, Position playerBase, int numberOfPawns, GameWindow game) {
        this(playerId, playerBase, numberOfPawns);
        this.game = game;
        
    }

    /**
     * Transforms the players choice of move into an Action
     * @param turn  The nr of turn (probably redundant data)
     * @return An action chosen by the player
     */
    @Override
    public PawnAction chooseAction(int turn) {
        Position source = game.getStartingPosition();
        Pawn actingPawn = null;
        //find the pawn in the clicked position
        for (Pawn pawn : this.getAlivePawns()){
            if (pawn.getPawnPosition()== source){
                actingPawn = pawn;
//                System.out.println("Player chosen pawn "+actingPawn.getPawnID() + " in position" + pawn.getPawnPosition().toString());
                break;
            }
                
        }
        //if no pawn found in that position return null
        if ( actingPawn == null )
            return null;
        
        // else form an action object
        Position target = game.getTargetPosition();
//        System.out.println("Moving from "+source + " to Target Position  "+ target);
        PawnAction action = new PawnAction(false, actingPawn, source, target);
        return action;
        
    }

    /**
     * A necessary override without any particular use at present
     */
    @Override
    public void finishGame() {
        System.out.println("Human Player finished game");
    }

    /**
     * A necessary override without any particular use at present. May be used for recording of actions!
     * @param chosenAction the chosen action by the agent
     */
    @Override
    public void learnFromAction(PawnAction chosenAction) {
        return; //no need to implement this for this type of player
    }
    
}

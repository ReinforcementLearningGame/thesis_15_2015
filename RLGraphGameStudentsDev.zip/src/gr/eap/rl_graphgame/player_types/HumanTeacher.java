/*
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.player_types;

import gr.eap.rl_graphgame.helpers.SinglePlayerGame;
import java.io.File;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;
import gr.eap.rl_graphgame.helpers.GameWindow;
import gr.eap.rl_graphgame.rl_agents.TDAgent;

/**
 * An extention to the Human Player Class. It allows the user to teach the AI how to play
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class HumanTeacher extends HumanPlayer{
    /**
     * The neural net of the AI that is going to be trained
     */
    private File neuralNetFilename;
    /**
     * The AI Agent that will be trained
     */
    private final TDAgent decisionMaker;

    /**
     * Constructor
     * @param playerId The players ID nr
     * @param opponentId The opponent players id nr
     * @param playerBase The players base position
     * @param numberOfPawns The nr of player's pawns
     * @param world game world
     * @param game  the game session / gui
     */
    public HumanTeacher(int playerId, int opponentId, Position playerBase, int numberOfPawns, World world, GameWindow game) {
        super(playerId, playerBase, numberOfPawns);
        switch (playerId){
            case Settings.WHITE_ID:
                this.neuralNetFilename = Settings.WHITE_NEURAL_NET_FILENAME;
                break;
            case Settings.BLACK_ID:
                this.neuralNetFilename = Settings.BLACK_NEURAL_NET_FILENAME;
                break;
            default:
                System.out.println("invalid player id");
        };
        
        this.decisionMaker = new TDAgent(this, world, this.neuralNetFilename );
        this.game =  game;
    }
    
    /**
     * Trains the AI Agent with the actions of the user
     * @param chosenAction The action chosen by the user
     */
    @Override
    public void learnFromAction(PawnAction chosenAction) {
        
        decisionMaker.learnFromAction(chosenAction);
        
    }
    
    /**
     * Initialize the AI Agent of the Teacher
     */
    public void initialize(){
        decisionMaker.initialize();
    }
    
    /**
     * Wrap up the learning procedure and record keeping when the game ends
     */
    @Override
    public void finishGame() {
        decisionMaker.endOfGame();
        
    }
    
    
    
}

/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.environment;

import java.util.ArrayList;
import gr.eap.rl_graphgame.player_types.Player;

/**
 *A class to provide the functionality of the pawns in the game
 * 
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class Pawn {
    
    /**
     * a static variable to hold the total number of pawns created at any time
     */
    private static int gamePawns = 0;
    
    /**
     * A number that individually and uniquely identifies the Pawn
     */
    private int pawnID;
    
    /**
     * the owner (player) of the pawn
     */    
    private Player owner;
    
    /**
     * The current Position of the pawn
     */
    private Position pawnPosition;
    
    /**
     * a boolean flag to show whether a pawn is alive or not
     */
    private boolean alive;
    
    /**
     * The constructor of pawn objects
     * @param player The owning player of the pawn
     */
    public Pawn(Player player){
        this.owner = player;
        this.gamePawns++; //increase the number of pawns of the game
        this.pawnID = this.gamePawns; //give the number of pawns as pawns id
        this.pawnPosition = player.getPlayerBase();        //set the pawn position inside the players base
        this.alive = true;  //ITS ALIIIIIIVE!!!!!
    }

    /**
     * A method that finds all available actions for a specific pawn during its turn.
     * You may override this method in order to alter its functionality
     * @return An ArrayList of PawnAction objects.
     */
    
    public ArrayList<PawnAction> findAvailableActions() {
        ArrayList<PawnAction> actions = new ArrayList<>();  //an array list to hold the actions we will find
        if (!this.isAlive()) return null;                   //if the pawn is not alive, don't check for moves
        
        //System.out.println("Player " + this.owner.getPlayerId()+ " Pawn "+this.pawnID+ " position "+this.pawnPosition );
        
        for(Position nextPosition: this.getPawnPosition().getNeighboors()){ //iterate through all the positions the pawn can move to (neighboring positions)
            if (Settings.ELIMINATION_ONLY){
                
                if (nextPosition.getOccupiedBy()== Settings.NONE_ID && nextPosition.getBaseOfPlayer()==Settings.NONE_ID){ //if the next position is not occupied by any Pawn
                    //create a new PawnAction object of Legal Move
                    //for the current Pawn, From the current position To the next position.
                    //By default new Actions are created as Exploiting (true) actions.
                    //this is later changed in case the action is taken while Exploring

                    PawnAction newAction = new PawnAction(true, this, this.getPawnPosition(), nextPosition);
                    actions.add(newAction);

                }
            } else {
                

                if ((nextPosition.getOccupiedBy()== Settings.NONE_ID && nextPosition.getBaseOfPlayer()!=this.owner.getPlayerId())
                        || (nextPosition.getBaseOfPlayer()!=this.owner.getPlayerId()&& nextPosition.getBaseOfPlayer()!= Settings.NONE_ID)){ //if the next position is not occupied by any Pawn
                    //create a new PawnAction object of Legal Move
                    //for the current Pawn, From the current position To the next position.
                    //By default new Actions are created as Exploiting (true) actions.
                    //this is later changed in case the action is taken while Exploring

                    PawnAction newAction = new PawnAction(true, this, this.getPawnPosition(), nextPosition);
                    actions.add(newAction);

                }
            }
        }//endfor
        
        //System.out.println("Available PawnAction List for pawn " + this.pawnID + " completed. Amount found "+ actions.size());
        if (actions.size() == 0) //if we didnt find any available actions then return null
            return null;
        else
            return actions;
    }
    
    /**
     * Executes the specified action for the pawn (moves the pawn)
     * @param action The PawnAction the pawn must make
     */
    public void movePawn(PawnAction action){
        Position tempPosition = this.getPawnPosition();  //temporarily store the pawns current position
        this.setPawnPosition(action.getTarget());     //move the Pawn to the new position
        if (tempPosition.getBaseOfPlayer() != this.getOwner().getPlayerId())    //if the pawn is in a position other than the players base
            tempPosition.freePosition();                //free the previous Position of the pawn unless it is a base
        else {
            this.getOwner().extractPawnFromBase();  //if the pawn was in the base, extract the pawn from the base of the player
            if (this.getOwner().getPawnsInBase() == 0) tempPosition.freePosition(); //if no more pawns were left in the base free the base of pawns
        }
            
        
        this.getPawnPosition().setOccupiedBy(this.owner.getPlayerId());   //set the new pawn's position to occupied by the pawn's owner
    }

    /**
     * Getter method for the Pawn's ID number
     * @return the pawns ID
     */
    public int getPawnID() {
        return pawnID;
    }

    /**
     * Setter method for the pawn's ID
     * @param pawnID the pawnID to set
     */
    public void setPawnID(int pawnID) {
        this.pawnID = pawnID;
    }

    /**
     * Getter method for the pawns owner
     * @return the player
     */
    public Player getOwner() {
        return owner;
    }

    /**
     * Setter method for the pawn's Owner
     * @param player the player to set
     */
    public void setOwner(Player player) {
        this.owner = player;
    }

    /**
     * Getter method for the pawns position
     * @return the pawnPosition
     */
    public Position getPawnPosition() {
        return pawnPosition;
    }

    /**
     * Sets the pawns position to the designated one
     * @param pawnPosition the Position to set
     */
    public void setPawnPosition(Position pawnPosition) {
        this.pawnPosition = pawnPosition;
        pawnPosition.setOccupiedBy(this.owner.getPlayerId());
    }

    /**
     * Checks if a pawn is alive
     * @return true if pawn is alive, false otherwise
     */
    public boolean isAlive() {
        return alive;
    }

    /**
     * Sets the alive state of the pawn
     * @param alive the alive state of the pawn
     */
    public void setAlive(boolean alive) {
        this.alive = alive;
    }
    
    /**
     * Resets the total number of pawns
     */
    public static void reset(){
        gamePawns = 0;
    }
    
    
}

/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.environment;

import java.util.ArrayList;
import gr.eap.rl_graphgame.player_types.Player;

/**
 * A class that describes all the functionality of a World object. A
 * world object represents the environment of the game whether it is a chessboard or map or graph.
 * Responsible for:
 * a) Examining/returning the valid moves of a player each turn 
 * b) Return the reward of a player's action.
 *
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public class World {

    /**
     * An integer that holds the current turn
     */
    private int turn;
    
    /**
     * a flag to mark whether the state of the game is a winning state for a
     * player
     */
    private boolean finalState;

    /**
     * an ArrayList of all the positions, nodes etc of the game board
     */
    public ArrayList<Position> positions;
    
    /**
     * The white player in the game
     */
    protected Player whitePlayer;
/**
 * The black player in the game
 */
    protected Player blackPlayer;

    /**
     * Creates a world object from a number of positions
     * @param positions the positions of the board
     */
    public World(ArrayList<Position> positions) {
        this.positions = positions;
        this.turn = 0;
        this.finalState = false;
        System.out.println("World ready.");
    }
    
     

    /**
     * checks whether the state of the game is final and returns the winner
     * @return the Player who is the winner of this state
     */
    public Player isFinalState() {
//        System.out.println("Final state check...");

        //if win by Elimination only is false check for winners by base conquering
        if (!Settings.ELIMINATION_ONLY){
            
            //check if the whitePlayer has one of his pawns in the opponents base
            for (Pawn pawn : whitePlayer.getOwnedPawns())  //for each pawn of the whitePlayer
                if (pawn.getPawnPosition() == blackPlayer.getPlayerBase()) //if the pawns position is in the black base
                    return whitePlayer; //return the whitePlayer that has his pawn in the opponents base as the winner

            for (Pawn pawn : blackPlayer.getOwnedPawns()) //for each pawn of the blackPlayer
                if (pawn.getPawnPosition() == whitePlayer.getPlayerBase()) //if the pawns position is in the white base
                    return blackPlayer; //return the whitePlayer that has his pawn in the opponents base as the winner
        }
        //if a player has no pawns in the game his opponent is the winner
        if (blackPlayer.getAlivePawns().isEmpty())
            return whitePlayer;
        else if (whitePlayer.getAlivePawns().isEmpty())
            return blackPlayer;
        else
            //return that no (null) player wins
            return null;
        
    }
    

    /**
     * kill the pawns of the defined player that cannot move
     *
     * @param player the player whose pawns will be checked
     * @return an ArrayList containing the killed pawns of the player
     */
    public ArrayList<Pawn> killPawns(Player player) {
        if (player == null) {
            System.out.println("Error. No player defined (to check for dead pawns).");
            return null;
        }
        //System.out.println("Checking for killed pawns");
        ArrayList<Pawn> killedPawns = new ArrayList<>();
        //System.out.println("Player  " + player.getPlayerId() + " live pawns " + player.getAlivePawns().size());
        for (Pawn pawn : player.getAlivePawns()) { //for each pawn of the currentPlayer
            if (pawn.findAvailableActions() == null && pawn.getPawnPosition()!=pawn.getOwner().getPlayerBase()) {  //if the pawn cannot act anymore and is not inside its base
                pawn.setAlive(false);                   //set pawn as not alive (kill pawn)
                pawn.getPawnPosition().freePosition(); //free the position of the pawn
                //System.out.println("I just killed pawn "+ pawn.getPawnID() + "of player "+pawn.getOwner().getPlayerId());
                killedPawns.add(pawn);
            }
        }
        return killedPawns;
    }

    /**
     * find white base
     * @return the position that is the White Players base
     */
    public Position findWhiteBase() {
        for (Position singlePosition : this.positions) {
            if (singlePosition.getBaseOfPlayer() == Settings.WHITE_ID) {
                return singlePosition;
            }
        }
        return null;
    }

    /**
     * find black base
     * @return the position that is the Black Players base
     */
    public Position findBlackBase() {
        for (Position singlePosition : this.positions) {
            if (singlePosition.getBaseOfPlayer() == Settings.BLACK_ID) {
                return singlePosition;
            }
        }
        return null;
    }
    
    /**
     * Apply an action to the World and move the next state
     * @param action The action that is applied
     */
    public void applyAction(PawnAction action){
        //get the pawn that will move
        Pawn actingPawn = action.getActivePawn();
        actingPawn.movePawn(action);
        //Kill Unmovable pawns of the opponent
        if (actingPawn.getOwner() == whitePlayer){
            //System.out.println("Killing unmovable Black Pawns");
            killPawns(blackPlayer);
        } else{
            //System.out.println("Killing unmovable White Pawns");
            killPawns(whitePlayer);            
        }
        
    }

    
    
    /**
     * resets the world in order to replay the same map from the start
     */
    public void resetMap(){
        //Reset all players
        whitePlayer.resetPlayer();
        blackPlayer.resetPlayer();
        
        //free all the positions that are not a player's base
        for (Position position: positions){
         if ( position.baseOfPlayer == Settings.NONE_ID){
             position.freePosition();
             //System.out.println("Position" + position+" freed");
         }
         
        }
    }
    
    
    

    /**
     * Get the White Player
     * @return the whitePlayer
     */
    public Player getWhitePlayer() {
        return whitePlayer;
    }

    /**
     * Set the White Player
     * @param whitePlayer the whitePlayer to set
     */
    public void setWhitePlayer(Player whitePlayer) {
        this.whitePlayer = whitePlayer;
    }

    /**
     * Get the Black Player
     * @return the blackPlayer
     */
    public Player getBlackPlayer() {
        return blackPlayer;
    }

    /**
     * Set the Black Player
     * @param blackPlayer the blackPlayer to set
     */
    public void setBlackPlayer(Player blackPlayer) {
        this.blackPlayer = blackPlayer;
    }
    
    /**
     * A method to get a reference to the opponent of a player
     * @param oneSide The player whose opponent we seek
     * @return the opponent Player
     */
    public Player getOpponentPlayer(Player oneSide){
        switch (oneSide.getPlayerId()) {
            case Settings.WHITE_ID:
                return blackPlayer;
            case Settings.BLACK_ID:
                return whitePlayer;
            default:
                System.out.println("Error while getting opponent. Null returned.");
        }
        return null;
    }
    
    

}

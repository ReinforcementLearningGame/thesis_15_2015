/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.environment;

/**
 *A class that defines the functionality of an "PawnAction". Actions are used by the AIAgent and Environment. Implementations of Actions
 * must extend this class to use the AI
 * @author Sarantinos Panagiotis
 */

public class PawnAction {

    
    /**
     * Exploiting action or not
     */
    private boolean exploiting; //flag if action is exploiting
    
    /**
     * references the pawn that makes the action
     */
    private Pawn activePawn; //the Pawn that makes this action
    
    /**
     * the initial/starting position of the pawn
     */
    private Position source;
    
    /**
     * the target position of the pawn
     */
    private Position target;
    
    /**
     * Constructor of a PawnAction
     * @param exploiting Boolean, true if the action is exploiting a policy or false if it is exploring
     * @param activePawn The Pawn that is making this action
     * @param source The starting position
     * @param target The target position
     */
    public PawnAction(boolean exploiting, Pawn activePawn, Position source, Position target) {
        this.exploiting = exploiting;
        this.activePawn = activePawn;
        this.source = source;
        this.target = target;
    }

    /**
     * Getter for the action's exploiting parameter.
     * @return true if exploiting false if exploring
     */
    public boolean isExploiting() {
        return exploiting;
    }

    /**
     * Sets the exploiting status of the move
     * @param exploiting set action as Exploiting (true) or Exploring (false)
     */
    public void setExploiting(boolean exploiting) {
        this.exploiting = exploiting;
    }

    /**
     * Gets the pawn that is making the action
     * @return the activePawn
     */
    public Pawn getActivePawn() {
        return activePawn;
    }

    /**
     * Sets the pawn that is making the action
     * @param activePawn the activePawn to set
     */
    public void setActivePawn(Pawn activePawn) {
        this.activePawn = activePawn;
    }


    /**
     * Gets the source position of the action
     * @return the source
     */
    public Position getSource() {
        return source;
    }

    /**
     * Sets the source position of the action
     * @param source the source to set
     */
    public void setSource(Position source) {
        this.source = source;
    }

    /**
     * Gets the target position of the action
     * @return the target
     */
    public Position getTarget() {
        return target;
    }

    /**
     * Sets the target position of the action
     * @param target the target to set
     */
    public void setTarget(Position target) {
        this.target = target;
    }
    
    /**
     * 
     * @return A string describing the action
     */
    public String toString(){
        return "Player "+ this.activePawn.getOwner().getPlayerId()+ ". Moving Pawn "+this.activePawn.getPawnID()+" From "+ this.source + " To " + this.target;
    }
      
    
    
}

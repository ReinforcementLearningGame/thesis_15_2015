/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.game_utilities;

import java.util.ArrayList;
import org.apache.commons.collections15.Transformer;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.World;


/**
 * A transformer of MapNodes into Strings. Used to label Nodes/Vertices on the game board.
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 * @param <MapNode> A MapNode object that will be transformed to a String
 */
public class NodeLabeller <MapNode> implements Transformer<MapNode,String> {
    
    private static ArrayList<Pawn> pawns = new ArrayList();

    public NodeLabeller(World gameWorld) {
        pawns.addAll(gameWorld.getBlackPlayer().getOwnedPawns());
        pawns.addAll(gameWorld.getWhitePlayer().getOwnedPawns());
    }
    
    /**
     * Overriden transform() method from Apache Commons interface
     * @param node the node that will be transformed
     * @return the String with which the node will be labeled
     */
    
    @Override
    public String transform(MapNode node) {
        for (Pawn aPawn : pawns){
            if ((aPawn.getPawnPosition() == node && aPawn.isAlive()))
                return ""+aPawn.getPawnID();
        }
        return "";
    }
    
    
}

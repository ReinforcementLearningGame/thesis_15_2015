/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.game_utilities;

import gr.eap.rl_graphgame.helpers.SinglePlayerGame;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.GraphMouseListener;
import edu.uci.ics.jung.visualization.control.PluggableGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.TranslatingGraphMousePlugin;
import java.awt.event.MouseEvent;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import gr.eap.rl_graphgame.helpers.GameWindow;
import gr.eap.rl_graphgame.player_types.Player;


/**
 * A pluggable mouse for single player games
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class SinglePlayerMouse extends PluggableGraphMouse implements GraphMouseListener{

    GameWindow game;
    Player user;
    int opponentId=0;
    MapNode startingPosition;
    MapNode targetPosition;
    
    public SinglePlayerMouse(GameWindow game, Player user) {
        this.game = game;
        this.user = user;
        this.add(new TranslatingGraphMousePlugin(MouseEvent.BUTTON2_MASK));
        this.add(new ScalingGraphMousePlugin(new CrossoverScalingControl(), 0, 1.1f, 0.9f));
        this.opponentId = user.getPlayerId() == Settings.WHITE_ID ? Settings.BLACK_ID : Settings.WHITE_ID; //if the player is WHITE the opponent is BLACK and vice versa
        System.out.println("Player Mouse configured.");
    }

    /**
     * What happens when the graph is clicked. No functionality.
     * @param v the object we clicked on
     * @param me the event
     */
    @Override
    public void graphClicked(Object v, MouseEvent me) {
    }

    /**
     * What happens when we press the mouse on a graph object
     * @param v the object we clicked on
     * @param me the event
     */
    @Override
    public void graphPressed(Object v, MouseEvent me) {
        MapNode position = (MapNode) v;
        if ( position.getOccupiedBy()== user.getPlayerId() && (game.getStartingPosition()==null || game.getTargetPosition()!=null)){
            game.setStartingPosition((MapNode) v);
            game.setTargetPosition(null);
            startingPosition = position;
            targetPosition = null;
            return;
        }                

        if (position == game.getStartingPosition() || game.getStartingPosition()==null){ //if the selected position is the same as the starting position or we haven't selected a valid starting position
            //game.log("Incorrect pick type A");
            game.setStartingPosition(null);
            game.setTargetPosition(null);
            return;
        }
        if (Settings.ELIMINATION_ONLY){
            if (MapNode.getContainingGraph().isSuccessor(game.getStartingPosition(),position)
                && (position.getOccupiedBy()== Settings.NONE_ID && position.getBaseOfPlayer()== Settings.NONE_ID)){
            game.log("Legal move.");
            game.setTargetPosition(position);
            targetPosition = position;
            game.unmarkMoves();
            game.markMove(startingPosition, targetPosition);
        } else {
                game.log("Illegal move selected.");
                game.setStartingPosition(null);
                game.setTargetPosition(null);
            }
        } else {
            if (MapNode.getContainingGraph().isSuccessor(game.getStartingPosition(),position)
                    && (position.getOccupiedBy()== Settings.NONE_ID || position.getBaseOfPlayer()==opponentId)&& position.getBaseOfPlayer()!=user.getPlayerId()){
                game.log("Legal move.");
                game.setTargetPosition(position);
                targetPosition = position;
                game.unmarkMoves();
                game.markMove(startingPosition, targetPosition);
            }
            else{
                game.log("Illegal move selected.");
                game.setStartingPosition(null);
                game.setTargetPosition(null);
            }
        }
        me.consume();


        
    }

    /**
     * What happens when we release the mouse on a graph object. No functionality.
     * @param v the object we clicked on
     * @param me the event
     */
    @Override
    public void graphReleased(Object v, MouseEvent me) {
    }
}

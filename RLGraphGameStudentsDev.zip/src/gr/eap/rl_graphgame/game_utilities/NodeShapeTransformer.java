/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.game_utilities;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import org.apache.commons.collections15.Transformer;
import gr.eap.rl_graphgame.graph_elements.MapNode;


/**
 * A transformer of MapNodes into Shapes. Used to paint Nodes/Vertices on the game board with different shapes based on whether the position is a Base or not.
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class NodeShapeTransformer implements Transformer<MapNode,Shape> {

/**
 * The Overriden transform() method from Apache Commons interface
 * @param node the node that will be transformed
 * @return the shape the node was transformed into
 */
    @Override
    public Shape transform(MapNode node) {
        if (node.getBaseOfPlayer() != 0 )
            return new Rectangle(-10, -10, 20, 20);
        else return new Ellipse2D.Double(-10, -10, 20, 20);
    }
    
}

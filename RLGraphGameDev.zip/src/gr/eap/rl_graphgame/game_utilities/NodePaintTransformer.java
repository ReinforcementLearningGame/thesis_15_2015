/*
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.game_utilities;

import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import java.awt.Color;
import java.awt.Paint;
import org.apache.commons.collections15.Transformer;

/**
 *
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class NodePaintTransformer implements Transformer<MapNode,Paint> {
    @Override
    public Paint transform(MapNode mn) {
        
        switch (mn.getBaseOfPlayer()){
            case Settings.WHITE_ID:
              return Color.WHITE;
            case Settings.BLACK_ID:
            return Color.BLACK;            
        }

        switch (mn.getOccupiedBy()){
            case Settings.NONE_ID:
              return Color.RED;  
            case Settings.WHITE_ID:
              return Color.WHITE;
            case Settings.BLACK_ID:
            return Color.BLACK;
        }
        return null;
    }
}

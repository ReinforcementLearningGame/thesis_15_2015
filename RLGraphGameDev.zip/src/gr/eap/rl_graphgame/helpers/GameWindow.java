/*
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers;

import edu.uci.ics.jung.algorithms.layout.ISOMLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.graph.DirectedSparseMultigraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;
import gr.eap.rl_graphgame.game_utilities.EdgeColorTransformer;
import gr.eap.rl_graphgame.game_utilities.NodeLabeller;
import gr.eap.rl_graphgame.game_utilities.NodePaintTransformer;
import gr.eap.rl_graphgame.game_utilities.NodeShapeTransformer;
import gr.eap.rl_graphgame.graph_elements.MapEdge;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import static gr.eap.rl_graphgame.helpers.SinglePlayerGame.gfm;
import gr.eap.rl_graphgame.player_types.Player;
import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * An abstract class for every GUI where a human player is involved
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */


public abstract class GameWindow {
    
    protected JDialog gameWindow;
    protected JPanel nextTurnPane;
    protected JButton nextTurnButton;
    protected JTextArea moveLog;
    protected JPanel statsPane;
    protected JLabel whitePawnsInBaseLabel;
    protected JLabel whitePawnsAliveLabel;
    protected JLabel blackPawnsInBaseLabel;
    protected JLabel blackPawnsAliveLabel;
    protected JScrollPane moveLogScroll;
    protected DirectedSparseMultigraph<MapNode, MapEdge> g;
    protected VisualizationViewer<MapNode,MapEdge> visualizationViewer;
    protected static GraphFileManager gfm;
    protected ArrayList<Position> map;
    protected MapNode startingPosition;
    protected MapNode targetPosition;
    protected World gameWorld;
    protected Player whitePlayer;
    protected Player blackPlayer;
    protected int turn;
    protected Player winner = null;
    
    /**
     * Constructor
     */
    GameWindow(){
        //create the new graph to be edited
        gfm = new GraphFileManager();
        g= gfm.loadGraphML(Settings.MAP_FILENAME);
        map = new ArrayList<Position>(g.getVertices());
        Collections.sort(map, (node1, node2) -> node2.getId() - node1.getId());
        turn = 0;
        
        //create the elements of the game
        createGame();
        
        //create the game screen
        createScreen();
    }
    
    /**
     * Creates the screen elements and paints the game map. The screen is common to all Single Player and Spectator modes
     */
    private void createScreen(){
        gameWindow = new JDialog();
        gameWindow.setModalityType(Dialog.ModalityType.APPLICATION_MODAL); //the dialog is modal to inhibit interaction with the rest of the menu
        gameWindow.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE); //dispose the dialog when close icon is clicked
        
        nextTurnPane = new JPanel();
        nextTurnButton = new JButton();
        moveLogScroll = new JScrollPane();
        moveLog = new JTextArea();
        
        statsPane = new JPanel();
        whitePawnsInBaseLabel = new JLabel();
        whitePawnsAliveLabel = new JLabel();
        blackPawnsInBaseLabel = new JLabel();
        blackPawnsAliveLabel = new JLabel();
        
        whitePawnsInBaseLabel.setText("White Pawns In Base: "+whitePlayer.getPawnsInBase());
        whitePawnsAliveLabel.setText("White Pawns Remaining: "+whitePlayer.getAlivePawns().size());
        blackPawnsInBaseLabel.setText("Black Pawns In Base: "+blackPlayer.getPawnsInBase());
        blackPawnsAliveLabel.setText("Black Pawns Remaining: "+blackPlayer.getAlivePawns().size());
        
        //The layout for the nodes in the editor
        Layout<MapNode, MapEdge> graphLayout = new ISOMLayout(g);
        graphLayout.setSize(new Dimension(1000,800));
        visualizationViewer = new VisualizationViewer<MapNode,MapEdge>(graphLayout);
        visualizationViewer.setPreferredSize(new Dimension(950,750));
        
        // set all the transformers and labels to make the graph more readable.
        visualizationViewer.getRenderContext().setVertexFillPaintTransformer(new NodePaintTransformer());
        visualizationViewer.getRenderContext().setVertexLabelTransformer(new NodeLabeller(gameWorld));
        visualizationViewer.getRenderContext().setEdgeLabelTransformer(new ToStringLabeller());
        visualizationViewer.getRenderContext().setVertexShapeTransformer(new NodeShapeTransformer());
        visualizationViewer.getRenderContext().setEdgeDrawPaintTransformer(new EdgeColorTransformer());
        
        //create the mouse interface.
        createMouseInterface(); 
        
        //add the visualization viewer to the game window
        gameWindow.getContentPane().add(visualizationViewer);
        
        // Adding the menu stuff.
        JMenuBar menuBar = new JMenuBar();
        
        JMenu fileMenu = new JMenu();
        fileMenu.setText("File");
        
        JMenuItem exitMenuItem = new JMenuItem();
        exitMenuItem.setText("Exit");
        exitMenuItem.setToolTipText("Exit Game and return to main menu");
        //add an action listener for the exit button
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuButtonAction(evt);
            }
        });
        fileMenu.add(exitMenuItem);
        
        menuBar.add(fileMenu);
        
        gameWindow.setJMenuBar(menuBar);
        
        
        
        JMenu miscMenu = new JMenu();
        miscMenu.setText("Miscellaneous");
        
        JMenuItem miscMenuItem = new JMenuItem();
        miscMenuItem.setText("Reorganize");
        miscMenuItem.setToolTipText("Reorganize the position of the Graph nodes");
        //add an action listener for the reorganize button
        miscMenuItem.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reorganizeMenuButtonAction(evt);
            }
        });
        miscMenu.add(miscMenuItem);
        
        menuBar.add(miscMenu);
        
        
        //////////
        
        nextTurnPane.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        nextTurnButton.setText("Next Turn");
        //add an action listener for the next Turn button
        nextTurnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextTurnButtonActionPerformed(evt);
            }

            
        });
        
        
        moveLog.setEditable(false);
        moveLog.setColumns(30);
        moveLog.setLineWrap(true);
        moveLog.setRows(5);
        moveLogScroll.setViewportView(moveLog);
        
        //I am not a JAVA Ninja. I just copied the following from another class that i constructed using the Designer mode of Netbeans. Hoorah!

        javax.swing.GroupLayout nextTurnPaneLayout = new javax.swing.GroupLayout(nextTurnPane);
        nextTurnPane.setLayout(nextTurnPaneLayout);
        nextTurnPaneLayout.setHorizontalGroup(
            nextTurnPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(nextTurnPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(nextTurnPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nextTurnButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(moveLogScroll, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addGroup(nextTurnPaneLayout.createSequentialGroup()
                        .addGroup(nextTurnPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(whitePawnsAliveLabel)
                            .addComponent(whitePawnsInBaseLabel)
                            .addComponent(blackPawnsAliveLabel)
                            .addComponent(blackPawnsInBaseLabel))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        nextTurnPaneLayout.setVerticalGroup(
            nextTurnPaneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, nextTurnPaneLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(whitePawnsAliveLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(whitePawnsInBaseLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(blackPawnsAliveLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(blackPawnsInBaseLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(moveLogScroll, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nextTurnButton)
                .addContainerGap())
        );
        
        gameWindow.add(BorderLayout.EAST,nextTurnPane);
        
        
        
        
        
        
        gameWindow.pack();
        gameWindow.setLocationRelativeTo(null);
        
        //taraaaaah!
        gameWindow.setVisible(true);
        
        
        
        
    }

    /**
     * The mouse interface to be used. Every game mode has different mouse settings.
     */
    protected abstract void createMouseInterface() ;
    
    /**
     * Create the game elements
     */
    protected abstract void createGame() ;
    
    /**
     * play the game
     */
    protected abstract void play();
    
    /**
     * Define the functionality of the next Turn button
     * @param evt the button event
     */
    protected abstract void nextTurnButtonActionPerformed(java.awt.event.ActionEvent evt);
    
    /**
     * exit button functionality
     * @param evt the button event
     */
    protected void exitMenuButtonAction(java.awt.event.ActionEvent evt) {                                           
        gameWindow.dispose();
    }
    
    /**
     * Reorganize button functionality
     * @param evt the button event
     */    
    protected void reorganizeMenuButtonAction(java.awt.event.ActionEvent evt) {
         
         Layout<MapNode, MapEdge> isomLayout = new ISOMLayout( g );
         visualizationViewer.setGraphLayout(isomLayout);
         visualizationViewer.repaint(); 
     }
    
    /**
     * Marks an action on the board
     * @param action the action to be marked
     */
    public void markMove(PawnAction action){
        MapNode start = (MapNode) action.getSource();
        MapNode end = (MapNode) action.getTarget();
        ArrayList<MapEdge> outEdges = new ArrayList<>(g.getOutEdges(start));
        for (MapEdge edge : outEdges){
            if (g.isDest(end , edge))
                    edge.setSelected(true);
        }
        visualizationViewer.repaint();
        
        
        
    }
    
    /**
     *Marks the edge between two vertices
     * @param start the starting vertex
     * @param end the ending vertex
     */
    public void markMove(MapNode start, MapNode end){
        ArrayList<MapEdge> outEdges = new ArrayList<>(g.getOutEdges(start));
        for (MapEdge edge : outEdges){
            if (g.isDest(end , edge))
                    edge.setSelected(true);
        }
        visualizationViewer.repaint();
        
        
        
    }
    
    /**
     * clears/unMarks all edges
     */
    public void unmarkMoves() {
        ArrayList<MapEdge> outEdges = new ArrayList<>(g.getEdges());
        for (MapEdge edge : outEdges)
            edge.setSelected(false);
        visualizationViewer.repaint();
    }
    
    /**
     * Appends data to the log
     * @param logString The data to append
    */
    public void log (String logString){
        moveLog.append(logString+"\n");
    }

    /**
     * get the position that the player defined as starting position for his action
     * @return the startingPosition
     */
    public MapNode getStartingPosition() {
        return startingPosition;
    }

    /**
     * Set the position that the player defined as starting position for his action
     * @param startingPosition the startingPosition to set
     */
    public void setStartingPosition(MapNode startingPosition) {
        this.startingPosition = startingPosition;
    }

    /**
     * Get the position that the player defined as target position for his action
     * @return the targetPosition
     */
    public MapNode getTargetPosition() {
        return targetPosition;
    }

    /**
     * Set the position that the player defined as target position for his action
     * @param targetPosition the targetPosition to set
     */
    public void setTargetPosition(MapNode targetPosition) {
        this.targetPosition = targetPosition;
    }
    
    /**
     * Get the world on which the session is played
     * @return The games world
     */
    public World getGameWorld(){
        return gameWorld;
    }
    
    /**
     * Get the graph of the game board
     * @return The graph of the game board 
     */
    public DirectedSparseMultigraph getGraph(){
        return g;
        
    }

    /**
     * End the game session and ask the player for repeating it.
     */
    protected void endGame() {
        Object[] options = {"Yes. One more time please!", "No. I've had enough."};
        int n = JOptionPane.showOptionDialog(null,
                        "Player "+this.winner.getPlayerId()+ " wins!\n"+"Do you want to play again?",
                        "End of Game Session.",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,
                        options,
                        options[0]);
        if (n == JOptionPane.YES_OPTION) {
            gameWorld.resetMap();
            visualizationViewer.repaint();
            winner = null;
            turn = 0;
        } else {
            whitePlayer = null;
            blackPlayer = null;
            g = null;
            gameWorld = null;
            MapNode.reset();
            MapEdge.reset();
            Pawn.reset();
            gameWindow.dispose();
        }
    }
}
/*
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers;

import edu.uci.ics.jung.graph.DirectedSparseMultigraph;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.SwingWorker;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;
import gr.eap.rl_graphgame.graph_elements.MapEdge;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import gr.eap.rl_graphgame.player_types.ComputerPlayer;
import gr.eap.rl_graphgame.player_types.Player;

/**
 * ComputerTrainer allows for the time consuming project of training the computer players to be conducted in the background.
 * It is used in conjuction with the training session JDialog which presents the results of the training
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class ComputerTrainer extends SwingWorker <Boolean, String> {

    
    
    /**
     * The training session for the computer players
     */
    ComputerTrainingSession session;
    
    /**
     * the environment of the game. The game world (board) in which the game will be played
     */
    private World gameWorld;
    /**
     * the white player
     */
    private ComputerPlayer whitePlayer;
    private final static int WHITE = 1;
    /**
     * the black player
     */
    private ComputerPlayer blackPlayer;
    private final static int BLACK = 0;
    
    /**
     * A draw value
     */
    private final static int DRAW = -1;
    
    /**
     * references to the players to determine the order of playing
     */
    private ComputerPlayer firstPlayer;
    private ComputerPlayer secondPlayer;
    
    /**
     * a parameter for counting the number of games played
     */
    private int gameCount;
    
    /**
     * the map of the game
     */
    private ArrayList<Position> map;
    
    /**
     * logs for player wins
     */
    private static Player lastWinner=null;
    private static int logTotalWhiteWins=0;
    private static int logTotalBlackWins=0;
    private static int logTotalDraws=0;
    private static float whiteWinPercent = 0;
    private static float blackWinPercent = 0;
    private static float drawsPercent = 0;
    
    private static ArrayList<Integer> last100GamesResults;
    private static int logLast100WhiteWins = 0;
    private static int logLast100BlackWins = 0;
    private static int logLast100Draws = 0;
    private static float whiteLast100WinsPercent = 0;
    private static float blackLast100WinsPercent = 0;
    private static float last100DrawsPercent = 0;
    
    
    private static float totalAverageTurns = 0;
    private static int last100AverageTurns = 0;
    private static int lastGameTurns=0;
    private static ArrayList<Integer> last100GamesTurns;
    
    /**
     * Constructor for the trainer.
     * @param session The ComputerTrainingSession that called this
     */
    public ComputerTrainer (ComputerTrainingSession session){
        System.out.println("Session Initiated");
        this.session = session;
        System.out.println("Creating Computer vs Computer Gameplay");
        //load the map of the game
        loadMap();
        System.out.println("Creating world map");
        //set the loaded map to the game world
        gameWorld = new World(map);
        System.out.println("Creating White Computer Player");
        
        //create Players
        this.whitePlayer = new ComputerPlayer(Settings.WHITE_ID, Settings.BLACK_ID, gameWorld.findWhiteBase(), Settings.NUMBER_OF_PAWNS, this.gameWorld );
        gameWorld.setWhitePlayer(whitePlayer);
        System.out.println("Creating Black Computer Player");
        this.blackPlayer = new ComputerPlayer(Settings.BLACK_ID, Settings.WHITE_ID, gameWorld.findBlackBase(), Settings.NUMBER_OF_PAWNS, this.gameWorld );
        gameWorld.setBlackPlayer(blackPlayer);
        
        //Set the player that plays first
        if (Settings.FIRST_PLAYER == Settings.WHITE_ID){
            firstPlayer = whitePlayer;
            secondPlayer = blackPlayer;
        } else{
            firstPlayer = blackPlayer;
            secondPlayer = whitePlayer;
        }
        //initialize the array lists that hold the results fot the last 100 games
        last100GamesResults = new ArrayList<>();
        last100GamesTurns = new ArrayList<>();
        
    }
    
    /**
     * The method that loads the Map of the games training session
     */
    private void loadMap() {
        System.out.println("Loading map from file:"+Settings.MAP_FILENAME.toString());
        DirectedSparseMultigraph graph = new GraphFileManager().loadGraphML(Settings.MAP_FILENAME);  //load graph from file
        System.out.println("Graph Loaded succesfully");        
        this.map = new ArrayList<Position>(graph.getVertices());    
        Collections.sort(this.map, (node1, node2) -> node2.getId() - node1.getId());        
    }
    

    /**
     * End the training session and prepare the game to be repeated if the player chooses to.
     */
    private void endSession() {
        System.out.println("Session Ended.");
        whitePlayer = null;
        blackPlayer = null;
        gameWorld = null;
        MapNode.reset();
        MapEdge.reset();
        Pawn.reset();
    }
    
    
    
    /**
     * The method that will do all the training in the background. Overrides SwingWorkers doInBackground() method
     * @return true when completed
     * @throws Exception In future versions the exception will be further specified to facilitate catching it.
     */
    @Override
    protected Boolean doInBackground() throws Exception {
        //initialize values for record keeping
        logTotalWhiteWins=0;
        logTotalBlackWins=0;
        logTotalDraws=0;
        
        logLast100WhiteWins = 0;
        logLast100BlackWins = 0;
        logLast100Draws = 0;
        
        totalAverageTurns = 0;
        last100AverageTurns = 0;
    
        System.out.println("Initiating Training");
        
        for ( gameCount=1; gameCount<=Settings.MAX_GAMES;gameCount++){  //Play the defined number of games, as in Settings.MAX_GAMES
            
            if (isCancelled()){ //if the SwingWorker is cancelled then end the session
                endSession();
                return false;
            }
//            if ((gameCount+1)%10 == 0)
//                System.out.println("********************P L A Y I N G****G A M E****"+(gameCount+1)+"************");
            //play a full game
            //initialize the ComputerPlayers logic
            whitePlayer.initialize();
            blackPlayer.initialize();
            playSingleGame(Settings.MAX_TURNS);
            //System.out.print("Finished game nr:"+(gameCount+1)+" in " + lastGameTurns+ " Turns . Winner is player ");

            //record statistics of victories
            
            if (lastWinner!=null){
//                System.out.println(lastWinner.getPlayerId());
                if (lastWinner==whitePlayer){
                    logTotalWhiteWins++;
                    logToLast100(WHITE , lastGameTurns);
                } else{
                    logTotalBlackWins++;
                    logToLast100(BLACK , lastGameTurns);
                }
                    
            } else {
                logTotalDraws++;
                logToLast100(DRAW , lastGameTurns);
//                System.out.println("NOONE");
            }
            
            totalAverageTurns =  totalAverageTurns*((float)(gameCount-1)/(float)gameCount) + (float)lastGameTurns/(float)gameCount;
            
            
            //Every 100 games played, send results to the ComputerTrainingSession thread
            if ( gameCount%100 == 0 || gameCount==Settings.MAX_GAMES){
                String publishLog = recordStatistics();
                
                //System.out.println(publishLog);
                publish(publishLog);
            }
            //calculate the training process
            int gameProgress = 100* (gameCount+1)/Settings.MAX_GAMES;
            
            //Set the progress of the process accordingly
            setProgress(gameProgress);
            gameWorld.resetMap();
        }
        endSession();
        System.out.println("Session ended normally");
        return true;
    }
    
    /**
     * The procedure of playing a single game
     * @param maxTurns The maximum allowed number of turns
     */
    private void playSingleGame(int maxTurns){
        int turn = 1;
        Player winner = null;
        PawnAction action;
//        System.out.println("*****************Playing**************");
//        System.out.println("World Settings. Positions :");
//        for (Position position : gameWorld.positions){
//            System.out.println("Position "+position.toString()+". Occupied by player"+position.getOccupiedBy()+". Base of player "+position.getBaseOfPlayer());
//        }
//        System.out.println("Pawn status");
//        for (Pawn pawn: whitePlayer.getAlivePawns())
//            System.out.println("Pawn "+pawn.getPawnID() + " in position" + pawn.getPawnPosition().toString());
//                
        while(winner == null && turn < maxTurns+1){ //repeat until there is a winner or the maximum allowed number of turns is reached
//            if ((turn)%100 == 0)
//                System.out.println("Playing Turn "+(turn));
            
            //first player chooses and makes a move
//            System.out.println("************** P L A Y E R ** 1****M O V E S***************");
            action = firstPlayer.chooseAction(turn);
            
//            System.out.println("Applying Action");
            gameWorld.applyAction(action);
            
//            System.out.println("ACTION APPLIED");
            
            //check if the first player won
            
            winner = gameWorld.isFinalState();
            
            
            //First player learn from his action
            firstPlayer.learnFromAction(action);
            
            if (winner == null){    //if the first player didn't win then let the second play
//                System.out.println("************** P L A Y E R ** 2****M O V E S***************");
                action = secondPlayer.chooseAction(turn);
                gameWorld.applyAction(action);
                winner = gameWorld.isFinalState();
                secondPlayer.learnFromAction(action);
            }
            
            //complementary learning in case of win. I'm unsure of the correctness of this. Uncomment only if you know what you are doing :-)
            if (winner == firstPlayer)
                secondPlayer.learnFromAction(action);
            else if (winner == secondPlayer)
                firstPlayer.learnFromAction(action);
                
            
            turn++;
        }
        lastWinner = winner;
        lastGameTurns = turn;
        //save the neural networks of the players if we have a winner. Draws don't count
        if (winner != null) {
//            System.out.println("Finishing game");
            firstPlayer.finishGame();
            secondPlayer.finishGame();
        }
        
        
        
    }
    
    /**
     * This method sends data to the ComputerTrainingSession
     * @param statistics the List of data sent by the ComputerTrainer
     */
    @Override
    protected void process (final List<String> statistics){
        //post the last entry in the statistics list on the training session GUI
        session.updateStatistics(statistics.get(statistics.size()-1));
        //log the results to file
        session.writeToLogFile(statistics);
        
    }
    
    /**
     * Executes when training is complete resetting the game and preparing it to be repeated if necessary.
     */
    @Override
    protected void done(){
        
        whitePlayer = null;
        blackPlayer = null;
        gameWorld = null;
        MapNode.reset();
        MapEdge.reset();
        Pawn.reset();
    }
    
    /**
     * Keeps track of the results of the last 100 games played
     * @param result A character corresponding to the last games result.
     */
    private void logToLast100(int result, int turns){
        if (last100GamesResults.size()==100){
            last100GamesResults.remove(0);
        }
        last100GamesResults.add(result);
        
        if (last100GamesTurns.size()==100){
            last100GamesTurns.remove(0);
        }
        last100GamesTurns.add(turns);
    }
    
    
    /**
     * records the statistics
     * @return A string containing the statistics to be published
     */
    private String recordStatistics(){
        logLast100WhiteWins = 0;
        logLast100BlackWins = 0;
        logLast100Draws = 0;
        
//        System.out.println("TAVT "+totalAverageTurns);
//        totalAverageTurns =  (int) ((float) totalAverageTurns*((float)(gameCount-1)/(float)gameCount) + (float)lastGameTurns/(float)gameCount);

        //total time statistics
        whiteWinPercent = 100*(float)logTotalWhiteWins/(float)gameCount;
        blackWinPercent = 100*(float)logTotalBlackWins/(float)gameCount;
        drawsPercent = 100*(float)logTotalDraws/(float)gameCount;

        //last 100 games statistics
        for (Integer record : last100GamesResults){
            switch (record){
                case WHITE:
                    logLast100WhiteWins++;
                    break;
                case BLACK:
                    logLast100BlackWins++;
                    break;
                case DRAW:
                    logLast100Draws++;
                    break;
            }
        }
        
        int turn = 0;
        for (Integer record : last100GamesTurns)
            turn=turn+record;

        whiteLast100WinsPercent = 100*(float) logLast100WhiteWins/100.00f;
        blackLast100WinsPercent = 100*(float)logLast100BlackWins/100.00f;
        last100DrawsPercent = 100 * (float) logLast100Draws/100.00f;
        last100AverageTurns =  turn/100;
        

        String publishLog = String.format("%.2f", whiteWinPercent)+":"+String.format("%.2f", blackWinPercent)+":"+String.format("%.2f", drawsPercent)+":"+(int)totalAverageTurns+":"+
                    String.format("%.2f", whiteLast100WinsPercent)+":"+String.format("%.2f", blackLast100WinsPercent)+":"+String.format("%.2f", last100DrawsPercent)+":"+ last100AverageTurns+":"+
                    logTotalWhiteWins+":"+logTotalBlackWins+":"+logTotalDraws+":"+gameCount;
        
        return publishLog;
        
    }
    
    
}

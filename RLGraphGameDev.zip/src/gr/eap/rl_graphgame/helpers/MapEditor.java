/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.helpers;

import gr.eap.rl_graphgame.helpers.editor_utilities.MyMouseMenus;
import gr.eap.rl_graphgame.helpers.editor_utilities.PopupVertexEdgeMenuMousePlugin;
import edu.uci.ics.jung.algorithms.layout.ISOMLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.layout.StaticLayout;
import edu.uci.ics.jung.graph.DirectedSparseMultigraph;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.EditingModalGraphMouse;
import edu.uci.ics.jung.visualization.control.ModalGraphMouse;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.game_utilities.NodePaintTransformer;
import java.awt.Dialog;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gr.eap.rl_graphgame.graph_elements.MapEdge;
import gr.eap.rl_graphgame.graph_elements.MapEdge.MapEdgeFactory;
import gr.eap.rl_graphgame.graph_elements.MapNode;
import gr.eap.rl_graphgame.graph_elements.MapNode.MapNodeFactory;
import org.apache.commons.io.FilenameUtils;


/**
 * An editor used for creating or editing graphs. Thanks to Dr. Greg M. Bernstein http://www.grotto-networking.com/ 
 * for his JUNG 2 Tutorials on editing JUNG 2 graphs.
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class MapEditor {
    /**
     * The JDialog window of the editor
     */
    private JDialog editorDialog;
    
    /**
     * A JFIlechooser to choose files for saving or loading
     */
    private JFileChooser fileChooser;
    
    /**
     * The filename of the map
     */
    private File filename;
    
    /**
     * the graph to be handled
     */
    private DirectedSparseMultigraph<MapNode, MapEdge> g;
    
    /**
     * Variables for visualization of graphs using JUNG 2 API
     */
    private VisualizationViewer<MapNode,MapEdge> vv;
    
    /**
     * The GraphFileManager that will handle the loading and saving operations
     */
    private static GraphFileManager gfm;
    
    /**
     * Constructor of the Map Editor
     */
    MapEditor (){
        //create the new graph to be edited
        g = new DirectedSparseMultigraph<MapNode, MapEdge>();
        gfm = new GraphFileManager(g);
        
        
    }
    
    /**
     * Creating the editors window and Editing the map
     */
    public void editMap() {
        try {
            //create a JDialog to hold the map editor stuff
            editorDialog = new JDialog();
            editorDialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL); //the dialog is modal to inhibit interaction with the rest of the menu
            editorDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE); //dispose the dialog when close icon is clicked
            
            //create a file chooser (not visible untill called)
            fileChooser = new JFileChooser();
            
            //set the file choosers directory to the current path of the application
            File f = new File(new File(".").getCanonicalPath());
            fileChooser.setCurrentDirectory(f);
            
            //for the nodes to be inserted, set this graph to be the containing graph (required for methods of the MapNode class)
            MapNode.setContainingGraph(g);
            
            //The layout for the nodes in the editor
            Layout<MapNode, MapEdge> layout = new StaticLayout(g);
            layout.setSize(new Dimension(300,300));
            vv = new VisualizationViewer<MapNode,MapEdge>(layout);
            vv.setPreferredSize(new Dimension(350,350));
            
            // Show vertex and edge labels
            vv.getRenderContext().setVertexFillPaintTransformer(new NodePaintTransformer());
            vv.getRenderContext().setVertexLabelTransformer(new ToStringLabeller());
            vv.getRenderContext().setEdgeLabelTransformer(new ToStringLabeller());
            
            // Create a graph mouse and add it to the visualization viewer
            EditingModalGraphMouse gm = new EditingModalGraphMouse(vv.getRenderContext(),
                    MapNodeFactory.getInstance(),
                    MapEdgeFactory.getInstance());
            
            
            // Trying out our new popup menu mouse plugin...
            PopupVertexEdgeMenuMousePlugin myPlugin = new PopupVertexEdgeMenuMousePlugin();
            
            // Add the popup menus for the edges and vertices to our mouse plugin.
            JPopupMenu edgeMenu = new MyMouseMenus.EdgeMenu(editorDialog);
            JPopupMenu vertexMenu = new MyMouseMenus.VertexMenu();
            myPlugin.setEdgePopup(edgeMenu);
            myPlugin.setVertexPopup(vertexMenu);
            gm.remove(gm.getPopupEditingPlugin());  // Removes the existing popup editing plugin
            
            gm.add(myPlugin);   // Add our new plugin to the mouse
            
            vv.setGraphMouse(gm);
            
            
            //JFrame editorDialog = new JFrame("Editing and Mouse Menu Demo");
            
            
            editorDialog.getContentPane().add(vv);
            
            // Let's add a menu for changing mouse modes
            JMenuBar menuBar = new JMenuBar();
            
            JMenu fileMenu = new JMenu();
            fileMenu.setText("File");
            
            JMenuItem loadMenuItem = new JMenuItem();
            loadMenuItem.setText("Load");
            loadMenuItem.setToolTipText("Load an existing Graph to edit");
            loadMenuItem.addActionListener(new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadMenuButtonAction(evt);
                }
            });
            fileMenu.add(loadMenuItem);
            
            
            JMenuItem saveMenuItem = new JMenuItem();
            saveMenuItem.setText("Save");
            saveMenuItem.setToolTipText("Save the Graph on the disk");
            saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    saveMenuButtonAction(evt);
                }
            });
            fileMenu.add(saveMenuItem);
            
            JMenuItem exitMenuItem = new JMenuItem();
            exitMenuItem.setText("Exit");
            exitMenuItem.setToolTipText("Exit Map Editor and return to main menu");
            exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    exitMenuButtonAction(evt);
                }
            });
            fileMenu.add(exitMenuItem);
            
            menuBar.add(fileMenu);
            
            
            JMenu modeMenu = gm.getModeMenu();
            modeMenu.setText("Mouse Mode");
            modeMenu.setToolTipText("Select mouse mode");
            modeMenu.setIcon(null); // I'm using this in a main menu
            modeMenu.setPreferredSize(new Dimension(80,20)); // Change the size so I can see the text
            
            menuBar.add(modeMenu);
            editorDialog.setJMenuBar(menuBar);
            gm.setMode(ModalGraphMouse.Mode.EDITING); // Start off in editing mode
            
            
            JMenu miscMenu = new JMenu();
            miscMenu.setText("Miscellaneous");
            
            JMenuItem miscMenuItem = new JMenuItem();
            miscMenuItem.setText("Reorganize");
            miscMenuItem.setToolTipText("Reorganize the position of the Graph nodes");
            miscMenuItem.addActionListener(new java.awt.event.ActionListener() {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    reorganizeMenuButtonAction(evt);
                }
            });
            miscMenu.add(miscMenuItem);
            
            menuBar.add(miscMenu);
            editorDialog.setLocationRelativeTo(null);
            editorDialog.pack();
            editorDialog.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(MapEditor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * Load menu button functionality
     * @param evt 
     */
    private void loadMenuButtonAction(java.awt.event.ActionEvent evt) {
        fileChooser.setFileFilter(Settings.MAP_FILE_FILTER);
        int returnVal = fileChooser.showOpenDialog(editorDialog);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            filename = fileChooser.getSelectedFile();
        } else {
        System.out.println("File access cancelled by user.");
        return;
        }
        
        try {
            g = gfm.loadGraphML(filename);
        } catch (NullPointerException nullPointerException) {
            System.out.println("No map selected");
            return;
        }
        ArrayList<MapNode> mapNodes = new ArrayList<MapNode>(g.getVertices());
        if (mapNodes == null) System.out.println(" Null array");
        for (MapNode node : mapNodes){
//            System.out.println("Node "+node.getName()+ " BaseOf"+ node.getBaseOfPlayer()+" "+ node.getOccupiedBy());
//            System.out.println(node.getNeighboors());
        }
//        System.out.println(g);
//        for (MapNode node : g.getVertices()){
//            System.out.println("Node "+node);
//            System.out.println(node.getNeighboors());
//        }
        
        Layout<MapNode, MapEdge> isomLayout = new ISOMLayout( g );
        vv.setGraphLayout(isomLayout);
        vv.repaint();
        
        
    }
    
    /**
     * Save menu button functionality
     * @param evt 
     */
    private void saveMenuButtonAction(java.awt.event.ActionEvent evt) {                                           
        fileChooser.setFileFilter(Settings.MAP_FILE_FILTER);
        int returnVal = fileChooser.showSaveDialog(editorDialog);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            filename = fileChooser.getSelectedFile();
            
            if (!FilenameUtils.getExtension(filename.getName()).equalsIgnoreCase("gxl"))
                filename = new File(filename.toString() + ".gxl");  // append .xml
            gfm.saveGraphML(filename);
            } else {
            System.out.println("File access cancelled by user.");
        }
    }
    
    /**
     * Exit menu button functionality
     * @param evt 
     */
    private void exitMenuButtonAction(java.awt.event.ActionEvent evt) {
        MapNode.reset();
        MapEdge.reset();
        editorDialog.dispose();
    }
    
     private void reorganizeMenuButtonAction(java.awt.event.ActionEvent evt) {
         
         Layout<MapNode, MapEdge> isomLayout = new ISOMLayout( g );
         vv.setGraphLayout(isomLayout);
         vv.repaint(); 
     }         
    
    
}

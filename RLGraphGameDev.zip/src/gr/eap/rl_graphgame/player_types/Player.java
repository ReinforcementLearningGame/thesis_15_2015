/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.player_types;

import java.util.ArrayList;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;

/**
 * An abstract class for all player objects of the game. It has the basic functionality a Player must have
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public abstract class Player {
    
    /**
     * the id of the player
     */
    protected int playerId;
    
    /**
     * An arrayList that references all the live pawns of the player
     */
    protected ArrayList<Pawn> ownedPawns;
    
    /**
     * the base of the player
     */
    protected Position playerBase;
    
    /**
     * the number of pawns still in the players base
     */
    protected int pawnsInBase=Settings.NUMBER_OF_PAWNS;
    
    /**
     * constructor for a player
     * @param playerId the players id
     * @param playerBase the position of the players base
     * @param numberOfPawns the number of pawns of the player
     */    
    public Player(int playerId, Position playerBase, int numberOfPawns){
        this.playerId = playerId;
        this.playerBase = playerBase;
        this.createPawns(numberOfPawns);
    }
    
    /**
     * 
     * @param numOfPawns 
     */
    private void createPawns(int numOfPawns){
        this.ownedPawns = new ArrayList<Pawn>();
        for (int i=0; i<numOfPawns;i++)
            this.ownedPawns.add(new Pawn(this));
    }
    
    /**
     * The player chooses an PawnAction from the possible actions
     * @param turn The turn currently playing
     * @return Returns an PawnAction chosen by the player
     */
    public abstract PawnAction chooseAction(int turn);
    
    /**
     * Learn from the action the player chose to make
     * @param chosenAction The chosen action 
     */
    public abstract void learnFromAction(PawnAction chosenAction);

    /**
     * get the id nr of the player
     * @return the playerId
     */
    public int getPlayerId() {
        return playerId;
    }

    /**
     * set the players id nr
     * @param playerId the playerId to set
     */
    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    /**
     * Get all the players pawns (dead or alive!!!)
     * @return the ownedPawns
     */
    public ArrayList<Pawn> getOwnedPawns() {
        return ownedPawns;
    }

    /**
     * set the pawns of the player
     * @param ownedPawns the ownedPawns to set
     */
    public void setOwnedPawns(ArrayList<Pawn> ownedPawns) {
        this.ownedPawns = ownedPawns;
    }
    
    /**
     * Get all the live pawns of the player
     * @return An arrayList of all the alive player's pawns
     */
    public ArrayList<Pawn> getAlivePawns(){
        ArrayList<Pawn> alivePawns = new ArrayList<Pawn>();
        for (Pawn pawn: ownedPawns){
            if (pawn.isAlive()==true){
                alivePawns.add(pawn);
            }
        }
        return alivePawns;
    }

    /**
     * get the players base
     * @return the playerBase
     */
    public Position getPlayerBase() {
        return playerBase;
    }

    /**
     * set the player's base
     * @param playerBase the playerBase to set
     */
    public void setPlayerBase(Position playerBase) {
        this.playerBase = playerBase;
    }
    
    /**
     * get the remaining pawns in the players base
     * @return The nr of pawns in the base
     */
    public int getPawnsInBase(){
        return pawnsInBase;
    }
    
    /**
     * extracts a pawn from the player's base
     */
    public void extractPawnFromBase(){
        pawnsInBase --;
    }
    
    
    /**
     * adds a pawn to the players base
     */
    public void addPawnToBase(){
        pawnsInBase ++;
    }
    
    
    /**
     * Resets the Player in order to repeat a game session
     */
    public void resetPlayer(){
        for (Pawn pawn: ownedPawns){
        //revive all pawns
        pawn.setAlive(true);
        //place the pawns in their bases
        pawn.setPawnPosition(playerBase);
        //reset the number of pawns occupying the players base
        pawnsInBase = Settings.NUMBER_OF_PAWNS;
        }
    }
    
    /**
     * Abstract method called at the end of a gaming session to wrap up everything
     */
    public abstract void finishGame();
    
    
}

/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.player_types;

import java.io.File;
import java.util.ArrayList;
import gr.eap.rl_graphgame.rl_agents.RLAgent;
import gr.eap.rl_graphgame.rl_agents.TDAgent;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;

/**
 * A computer player that uses an AI Agent to play the game
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public class ComputerPlayer extends Player {
    /**
     * the agent responsible for the Reinforcement Learning
     */
    private RLAgent decisionMaker;
    
    /**
     * The file that will hold the ANN to be created
     */
    public File neuralNetFilename;
    
    /**
     * Constructor
     * @param playerId  The Players ID nr
     * @param opponentId    The Opponent Players ID nr
     * @param playerBase    The base of the player
     * @param numberOfPawns The players nr of pawns
     * @param world         A reference to the world of the game
     */
    public ComputerPlayer(int playerId, int opponentId, Position playerBase, int numberOfPawns, World world) {
        super(playerId, playerBase, numberOfPawns);
        
        
        switch (playerId){
            case Settings.WHITE_ID:
                this.neuralNetFilename = Settings.WHITE_NEURAL_NET_FILENAME;
                break;
            case Settings.BLACK_ID:
                this.neuralNetFilename = Settings.BLACK_NEURAL_NET_FILENAME;
                break;
            default:
                System.out.println("invalid player id");
        }
        
        this.decisionMaker = new TDAgent(this, world, this.neuralNetFilename );
        }

    /**
     * chooses the appropriate action for the computer player using his decisionmaker (AI)
     * @return the chosen action
     */
    @Override
    public PawnAction chooseAction(int turn) {
        return decisionMaker.chooseAction(findAllActions(), turn); //find all the actions available and make a choice based on the criteria set        
    }
    
    
    @Override
    /**
     * 
     * @param chosenAction
     * @return a double[] for the square error of the players neural network at this moment/action
     */    
    public void learnFromAction(PawnAction chosenAction) {
        
        decisionMaker.learnFromAction(chosenAction);
        
    }

    /**
     * find all available actions for the player in the current turn
     * @return An array of all the actions a player can make
     */
    private ArrayList<PawnAction> findAllActions() {
//        System.out.println("================================");
//        System.out.println("Finding all actions for Player "+ this.playerId);
//        System.out.println("================================");
//        System.out.println();
        ArrayList<PawnAction> allActions = new ArrayList<>();
        ArrayList<PawnAction> singlePawnActions;
        if (this.getAlivePawns() == null) {
            //System.out.println("No more pawns left for player "+this.playerId);
            return null;
        }
        
        for (Pawn pawn : this.getAlivePawns()){
//            System.out.println("Checking actions for Pawn "+pawn.getPawnID());
//            System.out.println(pawn.findAvailableActions().size());
            singlePawnActions = pawn.findAvailableActions();
            if ( singlePawnActions != null )
                allActions.addAll(singlePawnActions);
        }
        //System.out.println("All Actions for Player "+this.playerId +" found. Amount is "+allActions.size());
        
        return allActions;
    }
    
    /**
     * Initialization of the players decision making agent (AIagent)
     */
    public void initialize(){
        decisionMaker.initialize();
    }

    /**
     * Called to wrap up the learning procedure when the game ends
     */
    @Override
    public void finishGame() {
//        System.out.println("Ending Game");
        decisionMaker.endOfGame();
        
    }
}

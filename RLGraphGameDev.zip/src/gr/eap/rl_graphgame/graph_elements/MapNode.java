/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.graph_elements;

import edu.uci.ics.jung.graph.Graph;
import java.util.ArrayList;
import org.apache.commons.collections15.Factory;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;

/**
 *This is the class that will be used to represent the game positions on a Graph. The game board is presented by nodes on a graph using JUNG library functionality.
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public class MapNode extends Position {
    
    /**
     * The graph in which this node (position) belongs to. This parameter has to
     * be set before any calls to getNeighboors method are made
     */
    private static Graph containingGraph;   
    
    
    /**
     * Constructor for a map node.
     */
    MapNode(){
        super();
        this.occupiedBy = Settings.NONE_ID;
        this.baseOfPlayer = Settings.NONE_ID;
    }
    
    /**
     * Sets the reference to the containing graph in which this node(vertex) belongs to
     * @param g the graph which contains the node
     */
    public static void setContainingGraph(Graph g){
        if (g == null) {
            System.out.println("Error! No containing Graph was specified for Map nodes");
            return;
        }
        containingGraph = g;
    }
    
    /**
     * Get the containing graph of this node
     * @return The graph Containing the node
     */
    public static Graph getContainingGraph(){
        return containingGraph;
    }
    
    @Override
    /**
     * Implements the method to get the neighboring nodes. In a directed
     * graph, neighbors are the Successors of the current node
     * A successor of vertex is defined as a vertex v
     * which is connected to vertex by an edge e, where
     * e is an incoming edge of v and an outgoing edge of vertex.
     */    
    public ArrayList<Position> getNeighboors(){
        
        if (containingGraph == null) {  //null is returned if no containing graph is specified. This prevents a NullPointerException from the getSuccessors(MapNode) method
            System.out.println("Containing Graph not set before calling accessing neighboors");
            return null;
        }
        
        if (containingGraph.getSuccessors(this)==null){ //if the node has no successors or the graph linked to it is wrong or empty
            System.out.println("Error! Provided containing Graph is empty or not related with vertex.");
            return null;
        }
        
        //create an ArrayList of the neighboring positions
        ArrayList<Position> poslist =  new ArrayList<Position> (containingGraph.getSuccessors(this));
        
        return poslist;
    }
    
    
    @Override
    /**
     * Set the node as a base of a player
     */
    public void setBaseOfPlayer(int playerID){
        //make a list of all the nodes in the graph
        ArrayList<MapNode> allMapNodes = new ArrayList<MapNode> (containingGraph.getVertices());
        for (MapNode node : allMapNodes) {      //for each node in the graph
            if (node.baseOfPlayer == playerID) { //if the node has been designated as player's base
                node.baseOfPlayer = Settings.NONE_ID; //set the node to noone's base
                node.occupiedBy = Settings.NONE_ID; //also set occupation to noone
                break;  //break the iteration as there is no need to search any further
            }
            
        }
            this.baseOfPlayer = playerID;
            this.occupiedBy = playerID;
            
        
    }
    
    
    @Override
    /**
     * a method required for labeling and debugging purposes
     */
    public String toString(){
        return this.name;
    }

    /**
     * Resets the class of MapNode in order to create new maps
     */
    public static void reset() {
        totalPositions = 0;
        containingGraph = null;
    }
    
    /**
     * This is a factory (see design patterns) for creating Node Objects
     */
    public static class MapNodeFactory implements Factory<MapNode> {
        private static MapNodeFactory instance = new MapNodeFactory();
        
        private MapNodeFactory(){
            
        }
        
        public static MapNodeFactory getInstance(){
            return instance;
        }
        
        /**
         *Overrides the create method from Apache Commons
         * @return A new MapNode
         */
        @Override
        public MapNode create() {
            if (containingGraph == null) {
                System.out.println("Error! No containing Graph has been specified. Unable to create Map Node");
                return null;
            }
            MapNode node = new MapNode();
            return node;
        }
        
    }
    
    
    
    
}

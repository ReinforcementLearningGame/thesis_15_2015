/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.graph_elements;

import java.io.Serializable;
import org.apache.commons.collections15.Factory;

/**
 * A class for the edges of the graph
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class MapEdge implements Serializable{
    /**
     * A variable to hold the total number of edges
     */
    private static int edgeCount = 0;
    
    /**
     * A default weight for the edge. Currently is 1. Weight is NOT used throughout this project. However it seemed a good choice to implement it for the sake of future changes
     */
    private double weight = 1;
    
    /**
     * The name of the Edge
     */
    private String name;
    
    /**
     * A boolean value for the selected state of an edge
     */
    private boolean selected = false;
    
    /**
     * A constructor of an edge with a specific name
     * @param name the name to set
     */
    public MapEdge(String name) {
            this.name = name;
    }
    
    /**
     * Get the weight of the edge
     * @return the weight of the edge
     */
    public double getWeight() {
            return weight;
    }
    
    /**
     * Set the weight of the edge
     * @param weight the weight to set
     */
    public void setWeight(double weight) {
            this.weight = weight;
    }
    
    /**
     * Get the edges name
     * @return the name of the edge
     */
    public String getName() {
            return name;
    }
    
/**
 * Set the edges name
 * @param name the name to set
 */
    public void setName(String name) {
            this.name = name;
    }
    
    /**
     * converts an edge to a string object
     * @return a string for the edge
     */
    public String toString() {
        return "";
        //return name+weight; //alternatively
        
    }

    /**
     * Checks if the edge is selected
     * @return the selected status of the edge
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * Set the selected status of the edge
     * @param selected the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    
    
    /**
     * This is a factory (see design patterns) for creating Edge Objects
     */
    public static class MapEdgeFactory implements Factory<MapEdge> {
        private static MapEdgeFactory instance = new MapEdgeFactory();
        
        private MapEdgeFactory (){
            
        }
        
        public static MapEdgeFactory getInstance(){
            return instance;
        }

        @Override
        public MapEdge create() {
            String name = "E"+edgeCount++;
            MapEdge edge = new MapEdge(name);
            return edge;
        }
        
    }
    
    /**
     * Resets the MapEdge Class in order to create a new graph/map
     */
    public static void reset(){
        edgeCount = 0;
    }
    
}

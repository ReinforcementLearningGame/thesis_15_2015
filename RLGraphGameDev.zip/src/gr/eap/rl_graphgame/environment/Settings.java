/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.environment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * * A class that holds all the information about the game settings
 * It contains default values and methods that change, load, save values to/from the disk
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public class Settings {
    
     /**
     *  *****D E F A U L T  ***  V A L U E S
     */
    
    public static final int DEFAULT_NUMBER_OF_PAWNS = 1;
    
    public static final boolean DEFAULT_ELIMINATION_ONLY = true;
    
    public static final int NONE_ID = 0,
                            WHITE_ID = 1,
                            BLACK_ID = 2;
    
    public static final double DEFAULT_MAX_REWARD = 1.0d;
    public static final double DEFAULT_MIN_REWARD = 0.0d;
    
    
       
    //Parameters for Training process
    public static final int DEFAULT_MAX_TURNS = 100;  //turns per game
    public static final int DEFAULT_MAX_GAMES = 5000; //games per training session
    
    //Parameters of RL process
    public static final double DEFAULT_E_GREEDY 	= 0.8d;
    public static final double DEFAULT_LAMBDA		= 0.7d;
    public static final double DEFAULT_GAMMA		= 0.9d;
    
    public static final String DEFAULT_WHITE_NEURAL_NET_FILENAME  = "white_Neural.nnf";
    

    public static final String DEFAULT_BLACK_NEURAL_NET_FILENAME  = "black_neural.nnf";
    
    //Environment parameters
    public static final String DEFAULT_MAP_FILENAME = "defaultmap.gxl";
    
    
    
    /**
     *  ******U S E R *** D E F I N E D *** G A M E *** S E T T I N G S *********
     */
    public static int NUMBER_OF_PAWNS = 1;
    public static boolean ELIMINATION_ONLY = false;
    public static int FIRST_PLAYER = WHITE_ID;
    public static double MAX_REWARD = 1.0d;
    public static double MIN_REWARD = 0.0d;
    

    //Parameters for Training process
    public static int MAX_TURNS = 100 ;  //turns per game
    public static int MAX_GAMES = 5000; //games per training session
    
    

    //Parameters of RL process
    
    //White Player RL
    public static double WHITE_E_GREEDY	= 0.8d;
    public static double WHITE_LAMBDA	= 0.7d;
    public static double WHITE_GAMMA	= 0.9d;
    public static File WHITE_NEURAL_NET_FILENAME  = new File("white_Neural.nnf");
    
    
    
    //Black Player RL
    public static double BLACK_E_GREEDY	= 0.8d;
    public static double BLACK_LAMBDA	= 0.7d;
    public static double BLACK_GAMMA	= 0.9d;
    public static File BLACK_NEURAL_NET_FILENAME  = new File ("black_Neural.nnf");
    
    public static File MAP_FILENAME = new File (DEFAULT_MAP_FILENAME);
    
    //Various settings
    public final static FileFilter SETTINGS_FILE_FILTER = new FileNameExtensionFilter("Settings File", "ini");
    public final static FileFilter MAP_FILE_FILTER = new FileNameExtensionFilter("Map File", "gxl");
    public final static FileFilter NEURAL_NET_FILE_FILTER = new FileNameExtensionFilter("Neural Network File", "nnf");
    
    
    /**
     * Sets the settings to their default values
     */
    public static void setToDefault(){
        NUMBER_OF_PAWNS = DEFAULT_NUMBER_OF_PAWNS;
        ELIMINATION_ONLY = DEFAULT_ELIMINATION_ONLY;
        FIRST_PLAYER = WHITE_ID;
        MAX_TURNS = DEFAULT_MAX_TURNS;  //turns per game
        MAX_GAMES = DEFAULT_MAX_GAMES; //games per training session
        WHITE_E_GREEDY	= DEFAULT_E_GREEDY;
        WHITE_LAMBDA		= DEFAULT_LAMBDA;
        WHITE_GAMMA		= DEFAULT_GAMMA;
        WHITE_NEURAL_NET_FILENAME    = new File(DEFAULT_WHITE_NEURAL_NET_FILENAME);
        
        BLACK_E_GREEDY          = DEFAULT_E_GREEDY;
        BLACK_LAMBDA		= DEFAULT_LAMBDA;
        BLACK_GAMMA		= DEFAULT_GAMMA;
        BLACK_NEURAL_NET_FILENAME    = new File(DEFAULT_BLACK_NEURAL_NET_FILENAME);
        MAP_FILENAME = new File(DEFAULT_MAP_FILENAME);
        MAX_REWARD = DEFAULT_MAX_REWARD;
        MIN_REWARD = DEFAULT_MIN_REWARD;
        
        
    }

    /**
     * Loads settings from a file
     * @param settingsFile The file that holds the settings data
     */
    public static void loadSettings(File settingsFile){
        FileReader fr = null;
        try {
            fr = new FileReader(settingsFile);
            BufferedReader reader = new BufferedReader(fr);
            String line = null;
            //read common Settings
            line = reader.readLine();
            MAX_TURNS = Integer.parseInt(extractString(line));
            line = reader.readLine();
            MAX_GAMES = Integer.parseInt(extractString(line));
            line = reader.readLine();
            NUMBER_OF_PAWNS = Integer.parseInt(extractString(line));
            line = reader.readLine();
            ELIMINATION_ONLY = Boolean.parseBoolean(extractString(line));
            line = reader.readLine();
            FIRST_PLAYER = Integer.parseInt(extractString(line));
            line = reader.readLine();
            MAX_REWARD = Double.parseDouble(extractString(line));
            line = reader.readLine();
            MIN_REWARD = Double.parseDouble(extractString(line));            
            
            //read white players settings
            line = reader.readLine();
            WHITE_E_GREEDY = Double.parseDouble(extractString(line));
            line = reader.readLine();
            WHITE_LAMBDA = Double.parseDouble(extractString(line));
            line = reader.readLine();
            WHITE_GAMMA = Double.parseDouble(extractString(line));
            line = reader.readLine();
            WHITE_NEURAL_NET_FILENAME = new File(extractString(line));
            
            //read black players settings
            line = reader.readLine();
            BLACK_E_GREEDY = Double.parseDouble(extractString(line));
            line = reader.readLine();
            BLACK_LAMBDA = Double.parseDouble(extractString(line));
            line = reader.readLine();
            BLACK_GAMMA = Double.parseDouble(extractString(line));
            line = reader.readLine();
            BLACK_NEURAL_NET_FILENAME = new File(extractString(line));
            
            //read the map filename
            line = reader.readLine();
            MAP_FILENAME = new File(extractString(line));
            
        } catch (FileNotFoundException ex) {
            System.err.println("Error loading settings.File not found! Defaulting.");
            setToDefault();
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            System.err.println("Error loading settings. Error reading file data! Defaulting. ");
            setToDefault();
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NumberFormatException ex){
            System.err.println("Error reading values. Invalid values in .INI file.");
            setToDefault();
        } finally {
            try {
                fr.close();
            } catch (IOException ex) {
                Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    /**
     * Breaks a string separated by ":" into parts and creates an array with the parts
     * @param line An array of strings
     * @return 
     */
    private static String extractString(String line){
        String[] parts = line.split(":");
        if (parts[0].equals((String) "Map file ") && parts.length>2)
            return parts[1]+":"+parts[2];
        
        return parts[1];        
    }
    
    /**
     * Saves the settings to a file
     * @param settingsFile the File the settings will be saved to
     */
    public static void saveSettings(File settingsFile){
        try {
            FileWriter fw = new FileWriter(settingsFile);
            BufferedWriter writer = new BufferedWriter(fw);
            //write common settings
            writer.write("Max Turns :");
            writer.write(MAX_TURNS+"");
            writer.newLine();
            writer.write("Max Games :");
            writer.write(MAX_GAMES+"");
            writer.newLine();
            writer.write("Number of Pawns per Player :");
            writer.write(""+Settings.NUMBER_OF_PAWNS);
            writer.newLine();
            writer.write("Win by elimination only :");
            writer.write(""+Settings.ELIMINATION_ONLY);
            writer.newLine();
            writer.write("First Player :");
            writer.write(""+Settings.FIRST_PLAYER);
            writer.newLine();
            writer.write("Max Reward :");
            writer.write(""+Settings.MAX_REWARD);
            writer.newLine();
            writer.write("Min Reward :");
            writer.write(""+Settings.MIN_REWARD);
            writer.newLine();
            //write white player settings
            writer.write("White e-greedy :");
            writer.write(WHITE_E_GREEDY+"");
            writer.newLine();
            writer.write("White Lambda :");
            writer.write(WHITE_LAMBDA +"");
            writer.newLine();
            writer.write("White Gamma :");
            writer.write(WHITE_GAMMA +"");
            writer.newLine();
            writer.write("White Neural Net filename :");
            writer.write(WHITE_NEURAL_NET_FILENAME.toString() +"");
            writer.newLine();
            
            
            //write black player settings
            writer.write("Black e-greedy :");
            writer.write(BLACK_E_GREEDY+"");
            writer.newLine();
            writer.write("Black Lambda :");
            writer.write(BLACK_LAMBDA +"");
            writer.newLine();
            writer.write("Black Gamma :");
            writer.write(BLACK_GAMMA +"");
            writer.newLine();
            writer.write("Black Neural Net filename :");
            writer.write(BLACK_NEURAL_NET_FILENAME.toString() +"");
            writer.newLine();
            
            writer.write("Map file :");
            writer.write(MAP_FILENAME.toString());
            writer.close();
            
        } catch (IOException ex) {
            System.err.println("Error writing data to save file!");
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
    }
    
    
}

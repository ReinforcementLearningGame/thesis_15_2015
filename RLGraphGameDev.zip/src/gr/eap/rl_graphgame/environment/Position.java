/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.environment;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * This is an abstract class that describes the minimum functionality that every Position object must have in the game to make RL functions work
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public abstract class Position implements Serializable{
    
    /**
     * The number of the total positions of the game board.
     */
    protected static int totalPositions;
    
    /**
     * The identifying number for the position
     */
    protected int id;
    
    /**
     * An optional string name for the position 
     */
    protected String name;
    
    /**
     * An integer defining the occupying/owning player (see Settings class). By default, no-one occupies a new position
     */
    protected int occupiedBy=Settings.NONE_ID;
    
    /**
     * an integer to represent whether the position is a players base. 0 None, 1 White, 2 Black
     */
    protected int baseOfPlayer = Settings.NONE_ID;
    
    /**
     * Constructor. Creates a position and names it by default  "P+id"
     */
    public Position(){
        totalPositions++;
        this.id=totalPositions;
        this.name="P "+id;
    }
    
    /**
     * Constructor. Creates a position with the specified name
     * @param name The name of the position to set
     */
    public Position(String name) {
        this.id = totalPositions++;
        this.name=name;
    }
    
    
    /**
     * Constructor. creates a position with the specified name and occupation status (owner player ID)
     * @param name The name of the position to set
     * @param occupiedBy The ID of the player that occupies the position
     */
    public Position(String name, int occupiedBy) {
        this.id = totalPositions++;
        this.name = name;
        this.occupiedBy = occupiedBy;
    }
    
    /**
     * returns an array of all the positions that a pawn can move to
     * @return a Position array
     */
    public abstract ArrayList<Position> getNeighboors();

    /**
     * Get the positions id number
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * Get the positions name
     * @return the name of the position
     */
    public String getName() {
        return name;
    }
    
    
    @Override
    /**
     * Position to string converter
     * @return the string of the position
     */
    public abstract String toString();

    /**
     * Set the positions name
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get which players pawn occupies this position
     * @return an integer for the occupying player
     */
    public int getOccupiedBy() {
        return occupiedBy;
    }

    /**
     * set the position as occupied by the defined player (int)
     * @param occupiedBy the player to occupy the position
     */
    public void setOccupiedBy(int occupiedBy) {
        this.occupiedBy = occupiedBy;
    }
    
    /**
     * free the position of any owner
     */
    public void freePosition(){
    this.occupiedBy = Settings.NONE_ID;
}

    /**
     * checks if the position is the base of a player
     * @return the id of the player who has a base in this position
     */
    public int getBaseOfPlayer() {
        return baseOfPlayer;
    }

    /**
     * Set a position to be the base of a player
     * @param playerID players id that holds this position as a base
     */
    public void setBaseOfPlayer(int playerID) {
        this.baseOfPlayer = playerID;
    }
}

/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRAN TY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.rl_agents;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import gr.eap.rl_graphgame.player_types.Player;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.Pawn;
import gr.eap.rl_graphgame.environment.Position;
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.environment.World;


/**
 * This is a reinforcement learning Agent, extending the RLAgent class in order to implement the RL algorithm of TD(λ) learning
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class TDAgent extends RLAgent{
    
    
    /**
     * The discount rate parameter
     */
    private double gamma;
    
    /**
     * the decaying factor of the eligibility traces
     */
    private double lambda;
    
    /**
     * The Filename where the ANN will be saved
     */
    private File neuralNetFileName;
    
    /**
     * The desired nr of output nodes of the ANN
     */
    private int outputNodes=1;
    
    
    //private LookUpTable neuralNetwork;
    
    /**
     * Constructor of the TD Agent
     */
    public TDAgent(){
        
    }
    
    /**
     * Constructor with parameters
     * @param player The player who is controlled by the agent
     * @param world The world that the agent/player will interact with
     * @param filename  the filename of the ANN to train
     */
    public TDAgent(Player player, World world, File filename ){
        this.player = player;
        this.world = world;
        this.RLMethod = "TD(λ)";
        this.turn = 1;
        this.neuralNetFileName = filename;
        int mapPositions = world.positions.size() - 2; // the number of positions a pawn can move to (total positions - 2 bases)
        
        //neural net input size is [2 x (  <MAP POSITIONS AS ABOVE> + <4 NODES FOR PAWN PCT> + <2 NODES FOR WINNER>) ] OR [ <MAP POSITIONS AS ABOVE>
        //comment out the appropriate line in accordance with which worldToNeuralInput() method you want to use
//        int inputNodes = 2 * mapPositions +6 );
        int inputNodes = mapPositions+3;
        int hiddenNodes = inputNodes/2;
        //set the opponent of the player
        switch (player.getPlayerId()) {
            case Settings.WHITE_ID:
                //opponent = world.getBlackPlayer();
                this.gamma = Settings.WHITE_GAMMA;
                this.lambda = Settings.WHITE_LAMBDA;
                this.eGreedyValue = Settings.WHITE_E_GREEDY;
                break;
            case Settings.BLACK_ID:
                //opponent = world.getWhitePlayer();
                this.gamma = Settings.BLACK_GAMMA;
                this.lambda = Settings.BLACK_LAMBDA;
                this.eGreedyValue = Settings.BLACK_E_GREEDY;
                break;
            default:
                System.out.println("Error setting opponent");
        }
        
        this.neuralNetwork = new NeuralNet(player.getOwnedPawns().size(), inputNodes, hiddenNodes, outputNodes, gamma, lambda, neuralNetFileName);
        
        
    }
    
    /**
     * Used to initialize the TD Agent before he starts making decisions.
     */
    @Override
    public void initialize(){
        neuralNetwork.setInput( worldToNeuralInput() ); //set the initial game state as an input to the neural network
        neuralNetwork.setOldOutputNode(neuralNetwork.response());
        neuralNetwork.updateElig();
        //System.out.println("TD agent for Player " + this.player.getPlayerId() + " initialized.");
    }
        
    
    /**
     * The method for choosing an action among the legal actions
     * @param legalActions the legal actions the player can make during his turn
     * @return the action chosen by the agent
     */
    
    @Override
    public PawnAction chooseAction(ArrayList<PawnAction> legalActions, int turn) {
//        System.out.println("Player " + player.getPlayerId()+" Nr of Pawns " + player.getAlivePawns().size() + ". Player choosing from "+legalActions.size());
        int chosenIndex = 0;
        double actionValue = 0;
        double largestValue = -Double.MAX_VALUE;
        PawnAction choice = null;
        //error checking
        if (legalActions == null){
            System.out.println("Error! No actions were passed (legalActions pointer NULL)");
            return null;
        }
        
        float choiceRoll = new Random().nextFloat();    //roll the "dice" to decide EXPLOIT or EXPLORE
        
//        System.out.println("=======================================");
//        System.out.println("Choosing action from available actions.");
//        System.out.println("=======================================");

        ArrayList <PawnAction> chosenActions = new ArrayList<>(); 
        
        if ( choiceRoll > eGreedyValue ){  //If ***E X P L O R I N G***
//            System.out.println("E X P L O R I N G");
            chosenIndex = new Random().nextInt(legalActions.size());    //generate a random index and
            choice = legalActions.get(chosenIndex);                     //choose the action of the index
            choice.setExploiting(false);                                //The action is NOT an exploiting one
//            System.out.println(choice.toString());
            
        } else {                                            // Else ***E X P L O I T I N G***
//            System.out.println("E X P L O I T I N G");
            for (PawnAction action : legalActions){         //for every legal action
//                System.out.println("Checking ..."+action.toString());
                actionValue = simulateMove(action);         //simulate the action and get the value of the emerging afterstate
//                System.out.println("...Value calculated"+actionValue);
                if (actionValue > largestValue) {           //IF the value of the action is the greatest yet encountered
                    largestValue = actionValue;             //set the largest value to this action's value
                    if (chosenActions.isEmpty()){                //IF the list of chosen actions is empty
                        chosenActions.add(action);               //add this action to the list
                    }
                        
                    else{                                        //ELSE IF the list is not empty
                        chosenActions.clear();                        // clear the list
                        chosenActions.add(action);                    // add this action as the only element
                    }
                    
                } else if (actionValue == largestValue){ //ELSE IF the value of the action is the same as the largest value encountered
                    chosenActions.add(action);                  // add this action to the list of chosen actions
                }                                        //ELSE DO NOTHING. Don't do anything with the action
                
                
            } //end for
            
            if ( chosenActions.size() > 1 ) { //if there are more than one actions with the SAME value of afterstate
                chosenIndex = new Random().nextInt(chosenActions.size());   //pick a random action from those actions arraylist
                choice = chosenActions.get(chosenIndex);
                choice.setExploiting(true);
            } else {
                choice = chosenActions.get(0);      //Else return the first (and only) entry of the array
                choice.setExploiting(true);
            }
            
        }//end else
        
//        System.out.println("Chosen "+choice.toString());
        return choice;
        
    }

    
    /**
     * simulates a move for a pawn and checks for the accumulated stateValue
     * @param action the action to be simulated
     * @return the estimated value of the occurring state (the first node of the ANN output)
     */
    public double simulateMove(PawnAction action) {
        Player opponent = world.getOpponentPlayer(player);
        double [] stateValue = new double[outputNodes];  //initialize a double array to hold the stateValue of the action
        Pawn pawn = action.getActivePawn(); //get the pawn whose move is simulated
        Position backUpPosition = pawn.getPawnPosition();//backup the current position of the pawn in order to simulate the move and then UNDO it.
        pawn.movePawn(action);//make the move of the pawn        
        ArrayList<Pawn> killedPawns = world.killPawns(opponent);//kill the opponents pawns but backup which pawns died in order to UNDO their death afterwards
        
        //check if the action results in a winning state for the pawns owner
        //System.out.println("Checking for final state");
        if (world.isFinalState() == player) {
//            System.out.println("winning move stateValue 1");
            stateValue [0] = Settings.MAX_REWARD;    //then the actions stateValue will be maximum because the state after the move will be final and the player wins
        } else {    //else return an approximation of the resulting states value using the NN
            neuralNetwork.setInput( worldToNeuralInput() );//set the emerging game state as an input to the neural network

//            System.out.println("Simulating move");
            stateValue = neuralNetwork.response();
//            System.out.println("simulated state"+stateValue[0]);
        }
        
        //UNDO the changes to the board
        pawn.getPawnPosition().setOccupiedBy(Settings.NONE_ID); //free the position that the pawn moved to
        pawn.setPawnPosition(backUpPosition); //restore the pawn to its original position
        if (pawn.getPawnPosition().getBaseOfPlayer()==pawn.getOwner().getPlayerId()) //if the move was made begining from the players base then restore the number of pawns in the players base
            pawn.getOwner().addPawnToBase();
        pawn.getPawnPosition().setOccupiedBy(pawn.getOwner().getPlayerId()); //set the restored position to "owned by the pawns owner"
        
        //Revive the dead pawns
        for (Pawn pawnToRevive : killedPawns){
            pawnToRevive.setAlive(true); //ITS ALIIIIIVE again!!!!
            pawnToRevive.getPawnPosition().setOccupiedBy(opponent.getPlayerId());
        }
        return stateValue[0];
    }

    /**
     * Learn from the last action the Agent made
     * @param chosenAction The chosen action
     */
    @Override
    public void learnFromAction(PawnAction chosenAction) {
        //this TD agent may only learn from the afterstate of each turn
        learnFromAfterstate();
        
    }
    
    /**
     * Learn from the afterstate that emerged after the agents last action
     */
    @Override
    public void learnFromAfterstate(){
        //apply the world stimulus (the afterstate of the action) to the ANN
//        System.out.println("*******Player***" + player.getPlayerId()+ " Learning from afterstate********");
        neuralNetwork.setInput( worldToNeuralInput());
        double [] reward = new double[outputNodes];
        
        if (world.isFinalState() == player){
            for (int i = 0 ; i < reward.length ; i++ )
                reward[i] = Settings.MAX_REWARD;
            
//            System.out.println("Winner is player "+player.getPlayerId());
            
        }
            
        else
            for (int i = 0 ; i < reward.length ; i++ )
                reward[i] = Settings.MIN_REWARD;
            
//       System.out.println("Rewarding..."+reward[0]);
       neuralNetwork.singleStep( reward );
        
        
    }

    /**
     * finalizing learning after the game has ended
     */
    @Override
    public void endOfGame() {
//        System.out.println("Game ended. Saving neuralNetworks");
        neuralNetwork.store();
    }
    
//    /**
//     * transforms the game state to a binary input for the neural network (FIRST OPTION. INPUT SIZE 
//     * @return an ArrayList to be used as input to the neural network
//     */
//    public ArrayList<Integer> worldToNeuralInput() {
//        ArrayList<Integer> input = new ArrayList<>();
//        //System.out.println("World to input");
//        for (Position position : world.positions) {
//            if (position.getBaseOfPlayer() != Settings.NONE_ID) {
//                continue; //do not enter base positions as input
//            }
//            if (position.getOccupiedBy() == Settings.WHITE_ID) { //if the position is occupied by a white pawn
//                //System.out.print("1.0 0.0 " );
//                input.add(1);
//                input.add(0);
//            } else if (position.getOccupiedBy() == Settings.BLACK_ID) { //if the position is occupied by a black pawn
//                //System.out.print("0.0 1.0 " );
//                input.add(0);
//                input.add(1);
//            } else { //if no pawn occupies the position
//                //System.out.print("0.0 0.0 " );
//                input.add(0);
//                input.add(0);
//            }
//        }
//        
//        //declare a variable to hold the percent of alive pawns for each player. Initiate it for current player
//        float livePawnsPct = (float) player.getAlivePawns().size() / (float) world.getOpponentPlayer(player).getAlivePawns().size();
//        
//        //calculate NN node inputs for current player's alive pawn percent
//        if (livePawnsPct >= 0.75d) {
//            //System.out.print("1.0 0.0 0.0 0.0 ");
//            input.add(1);
//            input.add(0);
//            input.add(0);
//            input.add(0);
//        } else if (livePawnsPct >= 0.5d) {
//            //System.out.print("0.0 1.0 0.0 0.0 ");
//            input.add(0);
//            input.add(1);
//            input.add(0);
//            input.add(0);
//        } else if (livePawnsPct >= 0.25d) {
//            //System.out.print("0.0 0.0 1.0 0.0 ");
//            input.add(0);
//            input.add(0);
//            input.add(1);
//            input.add(0);
//        } else {
//            //System.out.print("0.0 0.0 0.0 1.0 ");
//            input.add(0);
//            input.add(0);
//            input.add(0);
//            input.add(1);
//        }
//
//
//        //add 2 more nodes representing which player wins (or not)
//        if (player == world.isFinalState()) {
//            //System.out.print("1.0 0.0 ");
//            input.add(1);
//            input.add(0);
//        } else if (world.getOpponentPlayer(player) == world.isFinalState()) {
//            //System.out.print("0.0 1.0 ");
//            input.add(0);
//            input.add(1);
//        } else {
//            //System.out.print("0.0 0.0 ");
//            input.add(0);
//            input.add(0);
//        }
//        //System.out.println();
//        
//        //remove comment for debugging
////            System.out.println("Player "+this.player.getPlayerId());
////            for (Integer nodeInput : input){
////                System.out.print(" "+nodeInput);
////            }
////            System.out.println();
//        
//        return input;
//    }
    
    /**
     * transforms the game state to a binary input for the neural network (ALTERNATIVE INPUT METHOD)
     * @return an ArrayList to be used as input to the neural network
     */
    public ArrayList<Integer> worldToNeuralInput() {
        ArrayList<Integer> input = new ArrayList<>();
        //System.out.println("World to input");
        for (Position position : world.positions) {
            if (position.getBaseOfPlayer() != Settings.NONE_ID) {
                continue; //do not enter base positions as input
            }
            if (position.getOccupiedBy() == Settings.WHITE_ID) { //if the position is occupied by a white pawn
                //System.out.print("1.0 0.0 " );
                input.add(1);
            } else if (position.getOccupiedBy() == Settings.BLACK_ID) { //if the position is occupied by a black pawn
                //System.out.print("0.0 1.0 " );
                input.add(-1);
            } else { //if no pawn occupies the position
                //System.out.print("0.0 0.0 " );
                input.add(0);
            }
        }

        //declare a variable to hold the percent of alive pawns for each player. Initiate it for current player
        float livePawnsPct = (float) player.getAlivePawns().size() / (float) world.getOpponentPlayer(player).getAlivePawns().size();

        //calculate NN node inputs for current player's alive pawn percent
        if (livePawnsPct >= 0.75f) {
            //System.out.print("1.0 0.0 0.0 0.0 ");
            input.add(1);
            input.add(1);
        } else if (livePawnsPct >= 0.5f) {
            //System.out.print("0.0 1.0 0.0 0.0 ");
            input.add(1);
            input.add(0);
        } else if (livePawnsPct >= 0.25f) {
            //System.out.print("0.0 0.0 1.0 0.0 ");
            input.add(0);
            input.add(1);
        } else {
            //System.out.print("0.0 0.0 0.0 1.0 ");
            input.add(0);
            input.add(0);
        }

        //add 2 more nodes representing which player wins (or not)
        if ( player == world.isFinalState()) {
            //System.out.print("1.0 0.0 ");
            input.add(1);
        } else if (world.getOpponentPlayer(player) == world.isFinalState()) {
            //System.out.print("0.0 1.0 ");
            input.add(-1);
        } else {
            //System.out.print("0.0 0.0 ");
            input.add(0);
        }
        //System.out.println();
        
//            System.out.println("Player "+this.player.getPlayerId());
//            for (Integer nodeInput : input){
//                System.out.print(" "+nodeInput);
//            }
//            System.out.println();
        
        return input;
    }
    
    
}

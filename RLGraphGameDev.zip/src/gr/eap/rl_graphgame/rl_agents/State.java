/*
 * Copyright (C) 2015 Panagiotis Sarantinos pansarantin@yahoo.gr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.rl_agents;

import java.io.Serializable;

/**
 *
 * @author Panagiotis Sarantinos pansarantin@yahoo.gr
 */
public class State implements Serializable{
    private String stateID;
    private double stateValue;
    private double eligibilityTrace;
    
    
    //todo add equals() for state hashset.
    
    public State(String stateID, double stateValue, double eligibilityTrace){
        this.stateID = stateID;
        this.stateValue = stateValue;
        this.eligibilityTrace = eligibilityTrace;        
    }

    /**
     * @return the stateID
     */
    public String getStateID() {
        return stateID;
    }

    /**
     * @param stateID the stateID to set
     */
    public void setStateID(String stateID) {
        this.stateID = stateID;
    }

    /**
     * @return the stateValue
     */
    public double getStateValue() {
        return stateValue;
    }

    /**
     * @param stateValue the stateValue to set
     */
    public void setStateValue(double stateValue) {
        this.stateValue = stateValue;
    }

    /**
     * @return the eligibilityTrace
     */
    public double getEligibilityTrace() {
        return eligibilityTrace;
    }

    /**
     * @param eligibilityTrace the eligibilityTrace to set
     */
    public void setEligibilityTrace(double eligibilityTrace) {
        this.eligibilityTrace = eligibilityTrace;
    }
    
    public String toString(){
        return ("State ID:" + this.stateID + " / State Value:" + this.stateValue + "/ Eligibility:"+this.eligibilityTrace);
    }
    
}

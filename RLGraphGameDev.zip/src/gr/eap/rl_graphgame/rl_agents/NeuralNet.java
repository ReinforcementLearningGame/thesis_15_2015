/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.rl_agents;

import java.util.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;


class NeuralNet  {
    /**
     * The number of input Nodes of the NN
     */
    protected int nrOfInputNodes;
    /**
     * The number of hidden Nodes of the NN
     */
    protected int nrOfHiddenNodes;
    /**
     * The number of output Nodes of the NN
     */
    protected int nrOfOutputNodes;
    /**
     * first layer learning rate
     */
    private double  alpha;
    /**
     * second layer learning rate
     */
    private double  beta;
    /**
     * discount rate parameter
     */
    private double  gamma;
    /**
     * Trace decay parameter (should be <=gamma)
     */
    private double  lambda;
    /**
     * bias that each neuron has (input node 0)
     */
    private double  bias = 0.5;
    /**
     * array of input nodes (1st layer)
     */
    private double[] inputNode;
    /**
     * array of hidden nodes (2nd layer)
     */
    private double[] hiddenNode;
    /**
     * array of output nodes (3rd layer)
     */
    private double[] outputNode;
    /**
     * array used for updating weights
     */
    private double[] oldOutputNode;
    /**
     * error for each node
     */
    private double[] error;
    /**
     * the reward received for each decision
     */
    private double[] reward;
    /**
     * array of weights between layers 1->2
     */
    private double[][] w;
    /**
     * array of weights between layers 2->3
     */
    private double[][] v;
    /**
     * array of eligibility trace for weights v
     */
    private double[][][] ev;
    /**
     * array of eligibility trace for weights w
     */
    private double[][] ew;
    /**
     * number of pawns controlled by the agent
     */
    private int nrOfPawns;
    /**
     * the NN file name that stores the Weights and traces
     */
    private File neuralNetFilename;

    //todo add ruleset validator
    /**
     * Constructor of the neural network
     * @param nrOfPawns The number of pawns of the player
     * @param input the number of input nodes
     * @param hidden the number of hidden nodes
     * @param output the number of output nodes
     * @param gamma the discount rate parameter
     * @param lambda the decay rate parameter
     * @param neuralNetFilename  the filename of the save file of the ANN
     */
    protected NeuralNet(int nrOfPawns, int input, int hidden, int output, double gamma, double lambda, File neuralNetFilename) {
        
        this.nrOfPawns = nrOfPawns;
        nrOfInputNodes = input;
        nrOfHiddenNodes = hidden;
        nrOfOutputNodes = output;
        this.gamma = gamma;
        this.lambda = lambda;
        alpha = 1.0 / nrOfInputNodes;
        beta = 1.0 / nrOfHiddenNodes;

        inputNode = new double[nrOfInputNodes + 1];
        hiddenNode = new double[nrOfHiddenNodes + 1];
        outputNode = new double[nrOfOutputNodes];
        oldOutputNode = new double[nrOfOutputNodes];
        error = new double[nrOfOutputNodes];
        v = new double[nrOfInputNodes + 1][nrOfHiddenNodes + 1];
        w = new double[nrOfHiddenNodes + 1][nrOfOutputNodes];
        ev = new double[nrOfInputNodes + 1][nrOfHiddenNodes + 1][nrOfOutputNodes];
        ew = new double[nrOfHiddenNodes + 1][nrOfOutputNodes];

        this.neuralNetFilename = neuralNetFilename;
        
         // initiate the net
        initialize();
    }
        
    /**
     * Initializes weights and biases
     */
    private void initialize() {
        
        if (!load()){
            System.out.println("Randomly initiating neural network.");
            initWeights(); // if there is an error loading the weights from disk, the network is initialized from zero
        }
            
        
        inputNode[nrOfInputNodes] = bias; // last input node is set to bias
        hiddenNode[nrOfHiddenNodes] = bias; // last hidden node is set to bias

	}

    /**
     * Initializes the weights array and eligibility traces of all layers of nodes
     */
    private void initWeights() {

        int j, k, i;
        
        //initialize weights
        java.util.Date helpDate = new Date(); // variable seed used for randomization
        Random initWeight = new Random(helpDate.getTime());
        //initiate the weights within [-1,1]
        for (j = 0; j <= nrOfHiddenNodes; j++) {
            for (k = 0; k < nrOfOutputNodes; k++) {
                        w[j][k] = initWeight.nextDouble() - 0.5d;
                }
                for (i = 0; i <= nrOfInputNodes; i++) {
                        v[i][j] = initWeight.nextDouble() - 0.5d;
                }
        }
        
        //initialize eligibility traces
        for (j = 0; j <= nrOfHiddenNodes; j++) {
                for (k = 0; k < nrOfOutputNodes; k++) {
                        ew[j][k] = 0.0;
                        oldOutputNode[k] = 0.0;
                }
                for (i = 0; i <= nrOfInputNodes; i++) {
                        for (k = 0; k < nrOfOutputNodes; k++) {
                                ev[i][j][k] = 0.0;
                        }
                }
        }
        
    }
//        
//        /**
//         * A test method (not currently invoked by anything) to test that the file is saved/loaded correcry
//         */
//        private void test(){
//            System.out.println("Nr of Pawns"+nrOfPawns);
//            System.out.println("Nr of Input Nodes"+nrOfInputNodes);
//            System.out.println("Nr Of hidden Nodes"+nrOfHiddenNodes);
//            System.out.println("Nr of Output Nodes"+nrOfOutputNodes);
//            System.out.println("W array");
//            for (int i=0;i<=nrOfHiddenNodes;i++)
//                for (int j=0; j<nrOfOutputNodes;j++)
//                    System.out.print(". "+ w[i][j]);
//            System.out.println();
//            System.out.println("V array");
//            for (int i=0;i<=nrOfInputNodes;i++)
//                for (int j=0; j<=nrOfHiddenNodes;j++)
//                    System.out.print(". "+ v[i][j]);
//            System.out.println("End of file");
//        }

	/**
         * Store the weights of the Neural Network
         */
	void store() {
//            System.out.println("Storing");
//            test();
            ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new FileOutputStream(neuralNetFilename));
            out.writeObject(nrOfPawns);
            out.writeObject(nrOfInputNodes);
            out.writeObject(nrOfHiddenNodes);
            out.writeObject(nrOfOutputNodes);
            out.writeObject(w);
            out.writeObject(v);
            out.writeObject(ew);
            out.writeObject(ev);
            
        } catch (IOException ex) {
            Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                out.close();
            } catch (IOException ex) {
                Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            

	}

	/**
         * Loads the Neural Network node weights from a disk file
         */
	private boolean load() {
//            System.out.println("loading");
        try {
            Integer verifier;
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(neuralNetFilename));
            //verification process. check that the NN corresponds to the correct game
            verifier = (Integer) in.readObject();
            if (verifier != nrOfPawns)
                return false;
            verifier = (Integer) in.readObject();
            if (verifier != nrOfInputNodes)
                return false;
            verifier = (Integer) in.readObject();
            if (verifier != nrOfHiddenNodes)
                return false;
            verifier = (Integer) in.readObject();
            if (verifier != nrOfOutputNodes)
                return false;
            
            //then load the weights of the network
            w = (double[][]) in.readObject();
            v = (double[][]) in.readObject();
            ew = (double[][]) in.readObject();
            ev = (double[][][]) in.readObject();
            in.close();
            
        } catch (FileNotFoundException ex) {            
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Weight File not found! Initializing weights. Random values to be initialized.");
            return false;
        } catch (IOException ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Weight File is corrupted or contains incorrect Information. Random values to be initialized.");
            return false;
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error Loading Weights File. Random values to be initialized.");
            return false;
        } catch (Exception ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("General Error Loading Weights File. Random values to be initialized.");
            return false;
        }
//        test();
        return true;
        
	}
	

	/**
         * Calculates the response of the network based on the current network input.
         * @return the result of the sigmoid value function of the output nodes. An array of doubles
         */
	double[] response() {
		int i, j, k;
		hiddenNode[nrOfHiddenNodes] = bias;
		inputNode[nrOfInputNodes] = bias;
		for (j = 0; j < nrOfHiddenNodes; j++) {
			hiddenNode[j] = 0.0;
			for (i = 0; i <= nrOfInputNodes; i++) {
				hiddenNode[j] += inputNode[i] * v[i][j];
			}
			/*
			 * using sigmoid function to calculate the hidden nodes' value
			 * asymmetric sigmoid
			 */
			hiddenNode[j] = 1.0 / (1.0 + java.lang.Math.exp(-hiddenNode[j])); 
		}
		for (k = 0; k < nrOfOutputNodes; k++) {
			outputNode[k] = 0.0;
			for (j = 0; j <= nrOfHiddenNodes; j++) {
				outputNode[k] += hiddenNode[j] * w[j][k];
			}
			// using sigmoid function to calculate the output node's value
			outputNode[k] = 1.0 / (1.0 + java.lang.Math.exp(-outputNode[k]));
		}
//                System.out.println("Response "+outputNode[0]);
		return outputNode;
	}

	/**
         * Trains the network by updating the weights of the nodes backwards, according to the error observed. Implements backpropagation and eligibility traces
         */
	private void TDlearn() {
		int i, j, k;
		for (k = 0; k < nrOfOutputNodes; k++) {
			for (j = 0; j <= nrOfHiddenNodes; j++) {
				w[j][k] += beta * error[k] * ew[j][k];
				for (i = 0; i <= nrOfInputNodes; i++)
					v[i][j] += alpha * error[k] * ev[i][j][k];
			}
		}
	}
        
        /**
         * Updates the array of eligibility traces
         */
	protected void updateElig() {
		int i, j, k;
		double temp[] = new double[nrOfOutputNodes];

		for (k = 0; k < nrOfOutputNodes; k++) {
			temp[k] = outputNode[k] * (1 - outputNode[k]);
		}
		
		for (j = 0; j <= nrOfHiddenNodes; j++) {
			for (k = 0; k < nrOfOutputNodes; k++) {
				ew[j][k] = lambda * ew[j][k] + temp[k] * hiddenNode[j];
				for (i = 0; i <= nrOfInputNodes; i++) {
					ev[i][j][k] = lambda * ev[i][j][k] + temp[k] * w[j][k] * hiddenNode[j] * (1 - hiddenNode[j]) * inputNode[i];
				}
			}
		}
	}

	
        /**
         * Calculates the response of the ANN and corrects the weights (trains)
 with the  reward passed
         * @param stateValue the reward of the game state passed to the NN
         * @param finalState  boolean to specify if the state is final
         */
	protected void singleStep(double [] stateValue) {
            
            int k;
            
            response(); /* forward pass - compute activities */
            //System.out.println("Player "+ playerId +"  ANN response : "+outputNode[0]);
            
            reward = stateValue;
            
            for (k = 0; k < nrOfOutputNodes; k++) {
                    error[k] = reward[k] + gamma * outputNode[k] - oldOutputNode[k]; /* form errors */
                    //System.out.println("Player "+ playerId +" Error "+k + ": "+error[k]);
            }

            TDlearn(); /* backward pass - learning */
            response(); /* forward pass must be done twice to form TD errors */
//            System.out.println("Response after backprop"+outputNode[0]);
            for (k = 0; k < nrOfOutputNodes; k++) {
                    oldOutputNode[k] = outputNode[k]; /* for use in next cycle's TD errors */
            }
            
            updateElig(); /* update eligibility traces */
            
	}

	/**
         * Sets the oldOutputNode to a certain value. Used during initialization of TD agents. Implements the t=0 part of Sutton's pseudo-code
         * @param nodeValue 
         */
	void setOldOutputNode(double[] nodeValue) {
            if (nodeValue.length != oldOutputNode.length) {
                System.out.println("Error! Unable to set old output node. Different array sizes.");
            }
            for (int i=0; i<nodeValue.length ; i++)
                oldOutputNode[i]=nodeValue[i];
                
	}

	
	/**
         * Set the designated Array as input to the ANN
         * @param input The array/vector of inputs
         */
	void setInput(ArrayList<Integer> input) {
            
            
            if (input.size()> nrOfInputNodes){
                System.out.println("Error in NN input!ArrayList of inputs greater than expected input size.");
                return;
            }
            for (int i=0 ;i<input.size();i++)                    
                    this.inputNode[i] = (float) input.get(i);
                
            this.inputNode[nrOfInputNodes] = bias;
        }

	/**
         * Clears the Eligibility Traces. To be used by RL algorithms that require clearing the eligibility trace.
         */
	void clearEligTrace() {
		for (int j = 0; j <= nrOfHiddenNodes; j++) {
			for (int k = 0; k < nrOfOutputNodes; k++) {
				ew[j][k] = 0.0;
			}
			for (int i = 0; i <= nrOfInputNodes; i++) {
				for (int k = 0; k < nrOfOutputNodes; k++) {
					ev[i][j][k] = 0.0;
				}
			}
		}

	}

}

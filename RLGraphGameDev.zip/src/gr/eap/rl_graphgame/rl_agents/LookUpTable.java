package gr.eap.rl_graphgame.rl_agents;

/*
 * Copyright (C) 2015 Panagiotis Sarantinos pansarantin@yahoo.gr
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import gr.eap.rl_graphgame.environment.Settings;
import gr.eap.rl_graphgame.rl_agents.State;
import java.util.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 * A class that creates a neural net with custom settings from the caller.
 * Based on the Nonlinear TD/Backprop pseudo C-code
 * written by Allen Bonde Jr. and Rich Sutton in April 1992. 
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */

class LookUpTable  {
    
    protected int nrOfInputNodes, nrOfHiddenNodes, nrOfOutputNodes;
    
    private int nrOfPawns; // which player plays??

    private File tabularFilename; //the NN file name that stores wWeight
    private double gamma;
    
    //todo change arraylist to hash table
    private ArrayList<State> statesTable;
    private String stateID;
    private State previousAfterstate;
    private State newAfterstate;
    private double alpha ;

    /**
     * Constructor of the neural network
     * @param nrOfPawns The nr of pawns of the player
     * @param input the number of input nodes
     * @param hidden the number of hidden nodes
     * @param output the number of output nodes
     * @param gamma the discount rate parameter
     * @param lambda the decay rate parameter
     * @param neuralNetFilename  the filename of the savefile of the ANN
     */
    protected LookUpTable(int nrOfPawns, int input, int hidden, int output, double gamma, double lambda, File neuralNetFilename) {
        
        this.nrOfPawns = nrOfPawns;
        nrOfInputNodes = input;
        nrOfHiddenNodes = hidden;
        nrOfOutputNodes = output;
        alpha = 0.9;
        this.gamma = gamma;
        
        
        this.tabularFilename = neuralNetFilename;
        
        // initiate the value table
        if (!load()){
            System.out.println("Initiating new table.");
            statesTable = new ArrayList<State>();
        }
    }
//        
//        /**
//         * A test method (not currently invoked by anything) to test that the file is saved/loaded correcry
//         */
//        private void test(){
//            System.out.println("Nr of Pawns"+nrOfPawns);
//            System.out.println("Nr of Input Nodes"+nrOfInputNodes);
//            System.out.println("Nr Of hidden Nodes"+nrOfHiddenNodes);
//            System.out.println("Nr of Output Nodes"+nrOfOutputNodes);
//            System.out.println("W array");
//            for (int i=0;i<=nrOfHiddenNodes;i++)
//                for (int j=0; j<nrOfOutputNodes;j++)
//                    System.out.print(". "+ w[i][j]);
//            System.out.println();
//            System.out.println("V array");
//            for (int i=0;i<=nrOfInputNodes;i++)
//                for (int j=0; j<=nrOfHiddenNodes;j++)
//                    System.out.print(". "+ v[i][j]);
//            System.out.println("End of file");
//        }

	/**
         * Store the weights of the Neural Network
         */
	void store() {
            
            
//            System.out.println("Storing");
//            test();
            ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new FileOutputStream(tabularFilename));
            out.writeObject(nrOfPawns);
            out.writeObject(nrOfInputNodes);
            out.writeObject(nrOfHiddenNodes);
            out.writeObject(nrOfOutputNodes);
            out.writeObject(statesTable);
            
        } catch (IOException ex) {
            Logger.getLogger(LookUpTable.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                out.close();
            } catch (IOException ex) {
                Logger.getLogger(LookUpTable.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
            

	}

	/**
         * Loads the Neural Network node weights from a disk file
         */
	private boolean load() {
//            System.out.println("loading");
        try {
            Integer verifier;
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(tabularFilename));
            //verification process. check that the NN corresponds to the correct game
            verifier = (Integer) in.readObject();
            if (verifier != nrOfPawns)
                return false;
            verifier = (Integer) in.readObject();
            if (verifier != nrOfInputNodes)
                return false;
            verifier = (Integer) in.readObject();
            if (verifier != nrOfHiddenNodes)
                return false;
            verifier = (Integer) in.readObject();
            if (verifier != nrOfOutputNodes)
                return false;
            
            //then load the weights of the network
            statesTable = (ArrayList<State>) in.readObject();
            
            in.close();
            System.out.println("Loaded table of "+statesTable.size()+ " length");
            
        } catch (FileNotFoundException ex) {            
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Weight File not found! Initializing weights. Random values to be initialized.");
            return false;
        } catch (IOException ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Weight File is corrupted or contains incorrect Information. Random values to be initialized.");
            return false;
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error Loading Weights File. Random values to be initialized.");
            return false;
        } catch (Exception ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("General Error Loading Weights File. Random values to be initialized.");
            return false;
        }
//        test();
        return true;
        
	}
	
	double[] response() {
//            System.out.println("Response for state " + stateID);
            double[] stateValue = new double[nrOfOutputNodes];
            boolean found = false;
            //search the states table for a state with a known ID
            for (State state : statesTable){
//                System.out.println("State in table "+state.getStateID());
                if (state.getStateID().equals(stateID)){
                    stateValue[0] = state.getStateValue();
//                    System.out.println("Found state "+stateID);
                    found = true;
                    break;
                }
                    
                
            }
            //if there is no state with this ID add a new one to the table with Minimum value
            if (!found){
//                System.out.println("State " +stateID+ " not found...Response method creating it");
                State newState = new State(stateID, Settings.MIN_REWARD, 1);
//                System.out.println(newState);
                statesTable.add(newState);
//                System.out.println("Created new state. Array length..."+statesTable.size());
                stateValue[0] = newState.getStateValue();
//                System.out.println("value of new state "+stateValue[0] );
            }
//            System.out.println("Value is "+ stateValue[0]);
            return stateValue;   
	}

	
	private void TDlearn() {
            
            
	}
        
        
	protected void updateElig() {
            return;
		
	}

	
        
	protected void singleStep(double [] setReward) {
//            System.out.println("Action Chosen. AfterState is "+stateID + ". Reward is "+setReward[0]);
            boolean found = false;
            //search the states table for a state with a known ID
            if (statesTable == null){
                System.out.println("Empty state table");
            }
            for (State state : statesTable){
                if (state.getStateID().equals(stateID)){
                    newAfterstate = state;
//                    System.out.println("Lookup table Found state "+stateID);
                    found = true;
                    break;
                }
                
            }
            //if there is no state with this ID add a new one to the table with Minimum value
            if (!found){
                State newState = new State(stateID, Settings.MIN_REWARD, 1);
                statesTable.add(newState);
                newAfterstate = newState;
//                System.out.println("Lookup table created state "+newAfterstate);
            }
//            System.out.println("previous Afterstate value " + previousAfterstate.getStateValue());
            //TD learning
            previousAfterstate.setStateValue(previousAfterstate.getStateValue() + alpha * (setReward[0] + gamma * newAfterstate.getStateValue() - previousAfterstate.getStateValue()));
//            System.out.println("previous Afterstate"+previousAfterstate.toString()+ " value after learning " + previousAfterstate.getStateValue());
            previousAfterstate = newAfterstate;
//            for(State state: statesTable){
//                System.out.println(" "+state.getStateID()+" "+state.getStateValue());
//            }
            
            
            
        }
            

	/**
         * Sets the oldOutputNode to a certain value. Used during initialization of TD agents. Implements the t=0 part of Sutton's pseudo-code
         * @param afterstate 
         */
	void setOldOutputNode(double[] afterstate) {
//            if (afterstate.length != 1) {
//                System.out.println("Error! Check value array length");
//            }
            for (State state : statesTable){
                if (state.getStateID().equals(stateID))
                    previousAfterstate = state;
//                System.out.println("Found state "+stateID);
                break;
            }
                
	}

	
	/**
         * Set the designated Array as input to the ANN
         * @param input The array/vector of inputs
         */
	void setInput(ArrayList<Integer> input) {
            stateID = "";
            for (Integer digit : input)
                stateID += digit;
        }

	/**
         * Clears the Eligibility Traces. To be used by RL algorithms that require clearing the eligibility trace.
         */
	void clearEligTrace() {

	}

}

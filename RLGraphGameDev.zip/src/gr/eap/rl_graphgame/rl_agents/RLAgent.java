/* 
 * Copyright (C) 2015 Panagiotis Sarantinos <pansarantin@yahoo.gr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package gr.eap.rl_graphgame.rl_agents;

import java.util.ArrayList;
import gr.eap.rl_graphgame.player_types.Player;
import gr.eap.rl_graphgame.environment.PawnAction;
import gr.eap.rl_graphgame.environment.World;

/**
 *An abstract Agent that handles the decision making process and value assignment
 * @author Sarantinos Panagiotis pansarantin@yahoo.gr
 */
public abstract class RLAgent {
    /**
     * Which RL method does the RLAgent use to make decisions (i.e. TD(λ)-SARSA/Q, MC etc)
     */
    protected String RLMethod;
    
    /**
     * An integer number defining the turn of the game that is currently being played
     */
    protected int turn;
    
    /**
     * The neural network that will be trained for decision making purposes
     */
    protected NeuralNet neuralNetwork;
    
    /**
     * the ε-greedy value of RL Learning. Higher values mean that exploitation will occur more often than exploration
     */
    protected double eGreedyValue;
    
    /**
     * the player that uses the Agent
     */
    protected Player player;
    
//    /**
//     * The players opponent
//     */
//    protected Player opponent;
    
    /**
     * the world the agent is acting in
     */
    protected World world;
    
    
    /**
     * Chooses an PawnAction among all legal actions passed to the RL Agent
     * @param legalActions all the possible legal actions the agent may choose from in any game state
     * @param turn the turn being played
     * @return the chosen action
     */
    public abstract PawnAction chooseAction(ArrayList<PawnAction> legalActions, int turn);
    
    
    /**
     * applies the chosen action and calculates the values of the RL process
     * @param chosenAction the action chosen by the RL agent
     */
    public abstract void learnFromAction(PawnAction chosenAction);
    
    /**
     * The Agent learns by evaluating the afterstate that emerges after the players move
     */
    public abstract void learnFromAfterstate();
    
    
    /**
     * @return the RLMethod
     */
    public String getRLMethod() {
        return RLMethod;
    }

    /**
     * @param RLMethod the RLMethod to set
     */
    protected void setRLMethod(String RLMethod) {
        this.RLMethod = RLMethod;
    }

    /**
     * @return the turn
     */
    protected int getTurn() {
        return turn;
    }

    /**
     * @param turn the turn to set
     */
    protected void setTurn(int turn) {
        this.turn = turn;
    }

    /**
     * @return the neuralNetwork
     */
    protected NeuralNet getNeuralNetwork() {
        return neuralNetwork;
    }

    /**
     * @param neuralNetwork the neuralNetwork to set
     */
    protected void setNeuralNetwork(NeuralNet neuralNetwork) {
        this.neuralNetwork = neuralNetwork;
    }

    /**
     * @return the eGreedyValue
     */
    protected double geteGreedyValue() {
        return eGreedyValue;
    }

    /**
     * @param eGreedyValue the eGreedyValue to set
     */
    protected void seteGreedyValue(double eGreedyValue) {
        this.eGreedyValue = eGreedyValue;
    }

    /**
     * Defines what happens after the end of a training session
     */
    public abstract void endOfGame();
    
    /**
     * Initializes the agent to start learning
     */
    public abstract void initialize();
    
}
